<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et_pb_text_0_tb_footer.et_pb_text,.et_pb_text_5_tb_footer.et_pb_text,.et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_1_tb_footer{margin-bottom:15px!important}.et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et_pb_text_4_tb_footer h4,.et_pb_text_2_tb_footer h4,.et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_3_tb_footer,.et_pb_text_2_tb_footer,.et_pb_text_4_tb_footer{margin-bottom:20px!important}.et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}div.et_pb_section.et_pb_section_0{background-image:url(assets/uploads/2022/03/shutterstock_1877216707.jpg)!important}.et_pb_text_0 h1{font-weight:600;font-size:40px;color:#FFFFFF!important}.et_pb_section_1{border-bottom-width:1px;border-bottom-color:#efefef}.et_pb_section_1.et_pb_section{padding-right:0px;padding-left:0px}.et_pb_row_1.et_pb_row{padding-top:27px!important;padding-right:0px!important;padding-bottom:27px!important;padding-left:0px!important;padding-top:27px;padding-right:0px;padding-bottom:27px;padding-left:0px}.et_pb_row_1,body #page-container .et-db #et-boc .et-l .et_pb_row_1.et_pb_row,body.et_pb_pagebuilder_layout.single #page-container #et-boc .et-l .et_pb_row_1.et_pb_row,body.et_pb_pagebuilder_layout.single.et_full_width_page #page-container #et-boc .et-l .et_pb_row_1.et_pb_row{width:100%;max-width:100%}.et_pb_text_1.et_pb_text{color:#677a92!important}.et_pb_text_1{line-height:1.8em;font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:300;font-size:16px;line-height:1.8em;max-width:600px}.et_pb_text_1 h1{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-size:50px;line-height:1.3em}.et_pb_text_1 h2{font-weight:600;font-size:39px;color:#000000!important}.et_pb_text_2.et_pb_text{color:#000000!important}.et_pb_text_2{line-height:2em;font-size:16px;line-height:2em;max-width:600px}.et_pb_text_2 h2{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:300;font-size:40px;color:#212d3b!important;line-height:1.5em}.et_pb_image_0 .et_pb_image_wrap{border-radius:7vw 7vw 7vw 7vw;overflow:hidden;border-color:#0d4400;border-left-width:2vw;box-shadow:-30px 10px 0px -10px rgba(13,68,0,0.33)}.et_pb_image_0{width:100%;max-width:100%!important;text-align:left;margin-left:0}.et_pb_image_0 .et_pb_image_wrap,.et_pb_image_0 img{width:100%}.et_pb_column_1{padding-top:6%;padding-bottom:6%;padding-left:12%}@media  only screen and (max-width:980px){.et_pb_section_0.et_pb_section{padding-top:30px;padding-bottom:30px}.et_pb_text_0 h1,.et_pb_text_1 h2{font-size:30px}.et_pb_section_1{border-bottom-width:1px;border-bottom-color:#efefef}.et_pb_row_1.et_pb_row{margin-bottom:0px!important}.et_pb_text_1{line-height:1.8em}.et_pb_text_2{font-size:14px}.et_pb_image_0 .et_pb_image_wrap{border-left-width:2vw}.et_pb_image_0{text-align:center;margin-left:auto;margin-right:auto}.et_pb_column_1{padding-top:50px;padding-right:50px;padding-bottom:50px;padding-left:50px}}@media  only screen and (max-width:767px){.et_pb_section_0.et_pb_section{padding-top:30px;padding-bottom:30px}.et_pb_text_0 h1,.et_pb_text_1 h2{font-size:25px}.et_pb_section_1{border-bottom-width:1px;border-bottom-color:#efefef}.et_pb_text_1{line-height:1.8em}.et_pb_text_1 h1{font-size:36px}.et_pb_text_2{font-size:14px}.et_pb_image_0 .et_pb_image_wrap{border-left-width:2vw}.et_pb_column_1{padding-top:50px;padding-right:50px;padding-bottom:50px;padding-left:50px}}
</style>
   <div id="main-content">
      <article id="post-36" class="post-36 page type-page status-publish hentry">
         <div class="entry-content">
            <div class="et-l et-l--post">
               <div class="et_builder_inner_content et_pb_gutters3">
                  <div class="et_pb_section et_pb_section_0 et_pb_with_background et_section_regular">
                     <div class="et_pb_row et_pb_row_0">
                        <div class="et_pb_column et_pb_column_4_4 et_pb_column_0  et_pb_css_mix_blend_mode_passthrough et-last-child">
                           <div class="et_pb_module et_pb_text et_pb_text_0  et_pb_text_align_left et_pb_bg_layout_light">
                              <div class="et_pb_text_inner">
                                 <h1>About Us</h1>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="et_pb_with_border et_pb_section et_pb_section_1 et_section_regular">
                     <div class="et_pb_row et_pb_row_1">
                        <div class="et_pb_column et_pb_column_1_2 et_pb_column_1  et_pb_css_mix_blend_mode_passthrough">
                           <div class="et_pb_module et_pb_text et_pb_text_1  et_pb_text_align_left et_pb_bg_layout_light">
                              <div class="et_pb_text_inner">
                                 <h2>Why choose UsCannazon.com</h2>
                              </div>
                           </div>
                           <div class="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light">
                              <div class="et_pb_text_inner">
                                 <p>Uscannazon.com was created to alleviate growers, manufacturers and producers of their backed up inventory. As everyone in the cannabis business knows 2022 has been a rough year so far with prices dropping to record lows. This is why Uscannazon.com is so important to your business and let’s face it, your mental well being. </p>
                              </div>
                           </div>
                        </div>
                        <div class="et_pb_column et_pb_column_1_2 et_pb_column_2  et_pb_css_mix_blend_mode_passthrough et-last-child">
                           <div class="et_pb_with_border et_pb_module et_pb_image et_pb_image_0">
                              <span class="et_pb_image_wrap has-box-shadow-overlay aboutUsImg-overlay-main">
                                 <div class="box-shadow-overlay aboutUsImg-overlay"></div>
                                 <img width="474" height="321" src="assets/uploads/2022/03/Mask-Group-4.png" alt="" title="Mask Group 4" srcset="assets/uploads/2022/03/Mask-Group-4.png 474w, assets/uploads/2022/03/Mask-Group-4-300x203.png 300w" sizes="(max-width: 474px) 100vw, 474px" class="wp-image-33 aboutusBt-img">
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </article>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/front/about-us.blade.php ENDPATH**/ ?>