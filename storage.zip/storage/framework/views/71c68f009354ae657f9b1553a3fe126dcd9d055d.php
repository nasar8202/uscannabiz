<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Laravel Ecommerce | <?php echo $__env->yieldContent('title', ''); ?></title>


    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/jqvmap/jqvmap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/dist/css/adminlte.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/toastr/toastr.min.css')); ?>">
    <?php echo $__env->yieldContent('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/summernote/summernote-bs4.min.css')); ?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/responsive.css')); ?>">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    <link href="<?php echo e(asset('front/css/intlTelInput.min.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('extra-css'); ?>
</head>


<body class="<?php echo $__env->yieldContent('body-class', ''); ?>">

<?php echo $__env->make('front.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('front.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- jQuery -->
<script src="<?php echo e(URL::asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(URL::asset('admin/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(URL::asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(URL:: asset('admin/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(URL:: asset('admin/alert.js')); ?>"></script>
<script src="<?php echo e(URL:: asset('admin/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/intlTelInput-jquery.min.js')); ?>"></script>


<?php if(session()->has('success')): ?>
    <script type="text/javascript">  toastr.success('<?php echo e(session('success')); ?>');</script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script type="text/javascript"> toastr.error('<?php echo e(session('error')); ?>');</script>
<?php endif; ?>


<?php echo $__env->yieldContent('extra-js'); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecm\resources\views/front/layout/app.blade.php ENDPATH**/ ?>