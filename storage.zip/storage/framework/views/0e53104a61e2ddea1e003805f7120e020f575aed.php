
<?php $__env->startSection('title', 'Order Details'); ?>
<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="container">
                    <div class="card">
                        <div class="card-header">
                            

                        </div>
                        <form method="post" <?php if(isset($order)): ?> action="<?php echo e(route('submit-request-update')); ?>" <?php else: ?> action="<?php echo e(route('submit-request')); ?>"  <?php endif; ?>>
                            <?php echo csrf_field(); ?>
                            <?php if(isset($order)): ?>
                            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                            <?php endif; ?>
                            <input type="hidden" name="customer_id" value="<?php echo e($vender_request->customer_id); ?>">
                            <input type="hidden" name="customer_name" value="<?php echo e($vender_request->full_name); ?>">
                            <input type="hidden" name="phone_no" value="<?php echo e($vender_request->phone_num); ?>">
                            <input type="hidden" name="customer_email" value="<?php echo e($vender_request->email); ?>">
                            <input type="hidden" name="shipping_address" value="<?php echo e($vender_request->address); ?>">
                            
                            <input type="hidden" name="vendor_id" value="<?php echo e($vender_request->vendor_id); ?>">
                            <input type="hidden" name="shipping_city" value="<?php echo e($vender_request->city); ?>">
                            <input type="hidden" name="quantity" value="<?php echo e($vender_request->quantity); ?>">
                            <input type="hidden" name="vendor_req_id" value="<?php echo e($vender_request->id); ?>">
                            
                            <input type="hidden" name="total_amount" value="<?php echo e($product->product_current_price); ?>">
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <div class="card-body">
                            <div class="row">
                                
                                <?php if(isset($order)): ?>
                                <div class="col-md-5 float-right">
                                    <label for="">Order Status</label>
                                    <select name="order_status" id="order_status" class="form-control" data-order_id="<?php echo e($order->id); ?>">
                                        <option value="pending" <?php if($order->order_status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                                        <option value="shipped" <?php if($order->order_status == 'shipped'): ?> selected <?php endif; ?>>Shipped</option>
                                        <option value="completed" <?php if($order->order_status == 'completed'): ?> selected <?php endif; ?>>Completed</option>
                                        <option value="cancelled" <?php if($order->order_status == 'cancelled'): ?> selected <?php endif; ?>>Cancelled</option>
                                    </select>

                                </div>
                                <?php endif; ?>
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3 class="panel-title text-center"><i class="fa fa-user"></i> Vendor Details</h3>
                                        </div>
                                        <table class="table table-bordered">
                                            
                                            <tbody>
                                            <tr>
                                                <td style="width: 1%;">
                                                    <button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Customer"><i class="fa fa-user fa-fw"></i></button>
                                                </td>
                                                <td>
                                                    
                                                    <input type="hidden" name="vender_name" value="<?php echo e($vender_detail->name); ?>"> <?php echo e($vender_detail->name); ?>

                                                    
                                                </td>
                                            </tr>

                                            <tr>
                                                <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="E-Mail"><i class="fa fa-envelope-o fa-fw"></i></button></td>
                                                <td>
                                                    
                                                    <input type="hidden" name="vender_email" value="<?php echo e($vender_detail->email); ?>">
                                                        <a href="mailto:<?php echo e($vender_detail->email); ?>"><?php echo e($vender_detail->email); ?></a>
                                                    

                                                </td>
                                            </tr>

                                            <input type="hidden" name="vendor_request_id" value="<?php echo e($vender_request->id); ?>">

                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div class="panel-heading">
                                        <h3 class="panel-title text-center"><i class="fa fa-shopping-cart"></i> Order Details</h3>
                                    </div>
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <td style="width: 50%;font-weight: bold" class="text-left">Payment Address</td>
                                            <td style="width: 50%;;font-weight: bold" class="text-left">Shipping Address</td>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td class="text-left">
                                                <strong>Address</strong> : <?php echo e($vender_request->address); ?>

                                                <br>
                                                <strong>City</strong> :  <?php echo e($vender_request->city); ?>

                                            </td>
                                            <td class="text-left">
                                                <strong>Address</strong> : <?php echo e($vender_request->address); ?>

                                                <br>
                                                <strong>City</strong>  : <?php echo e($vender_request->city); ?>

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title text-center"> Order Item Details</h3>
                                </div>
                                <div class="table-responsive-sm">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="center">#</th>
                                            <th class="center">Image</th>
                                            <th>Item</th>
                                            
                                            <th class="right">Quantity</th>
                                            <th class="right">Sub Total</th>
                                            <th class="right">Total</th>
                                            <?php if(isset($order)): ?>
                                            <th class="right">Broker Commission</th>
                                            <?php endif; ?>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $counter = 1;
                                            // $subTotal = 0;
                                        ?>
                                         
                                            <tr>
                                                <td class="center"><?php echo e($counter++); ?></td>
                                                <td class="center">
                                                    <img src="<?php echo e(asset('uploads/products/'.$product->product_image)); ?>" width="50" height="50" alt="">
                                                </td>
                                                <td class="left strong">
                                                    <input type="hidden" name="" value="<?php echo e($product->product_name); ?>">
                                                    <?php echo e($product->product_name); ?>

                                                    
                                                </td>
                                                <td class="right"><?php echo e($vender_request->quantity); ?></td>
                                                <?php
                                                $total_price = $vender_request->quantity*$product->product_current_price;
                                                ?>
                                                <td class="right">$<?php echo e($product->product_current_price); ?></td>
                                                <td class="right">$<?php echo e($total_price); ?></td>
                                                <?php if(isset($order)): ?>
                                                <td class="right">$<?php echo e($order->broker_price); ?></td>
                                                <?php endif; ?>
                                            </tr>
                                            

                                        </tbody>
                                    </table>
                                    <?php if(isset($order) && $order->order_status == 'pending'): ?>
                                    
                                    <div class="col-md-4">
                                    <label for="category">Broker Commission Price</label>
                                    <input type="text" class="form-control" name="broker_price" id="broker_price" <?php if(isset($order)): ?> value="<?php echo e($order->broker_price); ?>" <?php endif; ?> placeholder="Amount" required >
                                    </div>  
                                    <?php elseif(!isset($order)): ?>
                                    <div class="col-md-4">
                                    <label for="category">Broker Commission Price</label>
                                    <input type="text" class="form-control" name="broker_price" id="broker_price"  value="" placeholder="Amount" required >
                                    </div>    
                                    <?php endif; ?>
                                    
                                <br>
                                </div>
                                
                            </div>
                        </div>
                        <?php if(isset($order) && $order->order_status == 'pending'): ?>
                        <button type="submit" class="float-right btn btn-primary">Update Request To Vendor</button>
                        <?php elseif(!isset($order)): ?>
                        <button type="submit" class="float-right btn btn-primary">Add Request To Vendor</button>
                        <?php endif; ?>
                    </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).on('change','#order_status',function(){
            let id = $(this).data('order_id');
            let val = $(this).val();

            $.ajax({
                type:"get",
                url:`<?php echo e(url('admin/'.request()->segment(2).'/changeOrderStatus')); ?>/${id}`,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data:{
                    val:val
                },
                success: function (data) {
                    if(data==0) {
                        toastr.error('Exception Here !');
                    }else{
                        toastr.success('Record Status Updated Successfully');
                    }
                    location.reload();
                }
            })
        });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/order/broker_show.blade.php ENDPATH**/ ?>