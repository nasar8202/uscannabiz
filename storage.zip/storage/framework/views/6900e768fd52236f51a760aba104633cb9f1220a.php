<?php $__env->startSection('title', 'Add Product'); ?>
<?php $__env->startSection('section'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/dropzone.css" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/dropzone/dist/basic.css')); ?>">
    <style>
        .switch {
            position: relative;
            display: block;
            width: 60px;
            height: 34px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }

        .help-block{
            color:red;
        }
        .has-error{
            border-block-color: red;
        }
    </style>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Product Form</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Product Form</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">

                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="#product" role="tab" data-toggle="tab">General</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="#related_products" role="tab" data-toggle="tab">Related Products</a>
                                    </li>
                                </ul>
                            </div>
                            <form class="category-form" method="post" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data">
                            <div class="tab-content ">
                                <div class="tab-pane active" role="tabpanel" class="tab-pane fade in active" id="product">

                                        <?php echo csrf_field(); ?>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Main Category*</label>
                                                    <select class="form-control <?php echo e($errors->has('main_category') ? 'has-error' : ''); ?>" name="main_category" id="main-category" required>
                                                        <option value="">Select Category</option>
                                                            <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php echo $errors->first('main_category', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                                
                                                
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Featured/New</label>
                                                    <select name="product_featured" id="" class="form-control">
                                                        <option value="Feature" <?php if(old('product_featured') == "Feature"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Featured</option>
                                                        <option value="New"  <?php if(old('product_featured') == "New"): ?> <?php echo e('selected'); ?> <?php endif; ?>>New</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Name*</label>
                                                    <input type="text" name="product_name" placeholder="Product Name" class="form-control <?php echo e($errors->has('product_name') ? 'has-error' : ''); ?>" value="<?php echo e(old('product_name')); ?>" >
                                                    <?php echo $errors->first('product_name', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Current Price*</label>
                                                    <input type="number" name="current_price" placeholder="Current Price" class="form-control <?php echo e($errors->has('current_price') ? 'has-error' : ''); ?>" value="<?php echo e(old('current_price')); ?>"  required>
                                                    <?php echo $errors->first('current_price', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product SKU*</label>
                                                    <input type="text" name="product_sku" placeholder="Product SKU" class="form-control <?php echo e($errors->has('product_sku') ? 'has-error' : ''); ?>" id="product_sku" value="<?php echo e(old('product_sku')); ?>"  required>
                                                    <span id="sku_span"></span>
                                                    <?php echo $errors->first('product_sku', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Slug*</label>
                                                    <input type="text" name="product_slug" class="form-control <?php echo e($errors->has('product_slug') ? 'has-error' : ''); ?>" placeholder="Product Slug" id="product_slug" value="<?php echo e(old('product_slug')); ?>"  required>
                                                    <span id="slug_span"></span>
                                                    <?php echo $errors->first('product_slug', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Sale</label>
                                                    <input type="checkbox" name="product_sale" class="form-control" id="product_sale" style="height: 20px;width: 20px;" value="yes" <?php if(old('product_sale') == 'yes'): ?> <?php echo e('checked'); ?> <?php endif; ?>>
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Sale(%)</label>
                                                    <input type="number" name="product_sale_percentage" placeholder="10" class="form-control" readonly id="product_sale_percentage" value="<?php echo e(old('product_sale_percentage')); ?>" required>
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Stock</label>
                                                    <input type="checkbox" name="product_stock" class="form-control" id="product_stock" style="height: 20px;width: 20px;" value="yes" <?php if(old('product_stock') == 'yes'): ?> <?php echo e('checked'); ?> <?php endif; ?>>
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Product Stock Qty</label>
                                                    <input type="number" name="product_stock_qty" class="form-control" placeholder="10" readonly id="product_stock_qty" value="<?php echo e(old('product_stock_qty')); ?>" required>
                                                </div>
                                                <div class="col">
                                                    <label for="switch">Status</label>
                                                    <label class="switch"><input type="checkbox" <?php if(old('status') == '1'): ?> <?php echo e('checked'); ?> <?php endif; ?> data-id="" id="status-switch" name="status" value="1">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Length</label>
                                                    <input type="text" name="length" placeholder="Length" class="form-control" id="length"  value="<?php echo e(old('length')); ?>">
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Width</label>
                                                    <input type="text" name="width" class="form-control" placeholder="Width" id="width" value="<?php echo e(old('width')); ?>">
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Height</label>
                                                    <input type="text" name="height" class="form-control" id="height" placeholder="Height" value="<?php echo e(old('height')); ?>">
                                                </div>
                                                <div class="col">
                                                    <label for="exampleInputEmail1">Weight</label>
                                                    <input type="text" name="weight" class="form-control" id="weight" value="<?php echo e(old('weight')); ?>" placeholder="Weight">
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="category">Description</label>
                                                    <textarea class="form-control <?php echo e($errors->has('main_category') ? 'has-error' : ''); ?>" name="description" id="description" placeholder="Description" required><?php echo e(old('description')); ?></textarea>
                                                    <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col">
                                                    <label for="category">Meta Title</label>
                                                    <input type="text" class="form-control <?php echo e($errors->has('meta-title') ? 'has-error' : ''); ?>" name="meta-title" id="meta-title"  value="<?php echo e(old('meta-title')); ?>" placeholder="Meta Title" required >
                                                    <?php echo $errors->first('meta-title', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                                <div class="col">
                                                    <label for="category">Meta Description</label>
                                                    <textarea class="form-control <?php echo e($errors->has('meta-description') ? 'has-error' : ''); ?>" name="meta-description" id="meta-description" placeholder="Meta Description" required><?php echo e(old('meta-description')); ?></textarea>
                                                    <?php echo $errors->first('meta-description', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                                <div class="col">
                                                    <label for="category">Meta Keywords</label>
                                                    <textarea class="form-control <?php echo e($errors->has('meta-keywords') ? 'has-error' : ''); ?>" name="meta-keywords" id="meta-keywords"  placeholder="Meta Keywords" required><?php echo e(old('meta-keywords')); ?></textarea>
                                                    <?php echo $errors->first('meta-keywords', '<p class="help-block">:message</p>'); ?>

                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <table class="table">
                                                    <tr>
                                                        <th>Product Image</th>
                                                        <th>Select Image</th>
                                                    </tr>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <img src="<?php echo e(asset('admin/images/placeholder.png')); ?>" alt="" id="img_0" style="height: 150px;width: 150px;">
                                                            </td>
                                                            <td>
                                                                <div class="input-group">
                                                                    <div class="custom-file">
                                                                        <input type="file" class="custom-file-input"  name="product_image_first" id="gallery_0" onchange="PreviewImage('0')" accept="image/*" required>
                                                                        <label class="custom-file-label" for="category-image">Choose file</label>
                                                                    </div>
                                                                    <?php echo $errors->first('product_image_first', '<p class="help-block">:message</p>'); ?>

                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <br>





















                                        </div>
                                        <br>
                                        <div class="row">
                                            <div class="gallery"></div>
                                        </div>

                                        <!-- /.card-body -->
                                </div>
                                <div class="tab-pane" role="tabpanel" class="tab-pane fade in active" id="additionalImages">
                                    <div class="col-md-12 text-right">
                                    </div>
                                    <table class="table">
                                        <tr>
                                            <th>Product Image</th>
                                            <th>Select Image</th>
                                        </tr>
                                        <tbody id="add_more">
                                        <tr >
                                            <td class="col-md-2">
                                                <img src="<?php echo e(asset('admin/images/placeholder.png')); ?>" alt="" id="img_1" style="height: 150px;width: 150px;">
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" name="product_image[]" id="gallery_1" onchange="PreviewImage('1')" accept="image/*">
                                                        <label class="custom-file-label" for="category-image">Choose file</label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="col-md-1">
                                                <input type="button" class="btn btn-md btn-primary" id="addMoreBtn" value="+" onclick="addMorePictures(1)"/>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" role="tabpanel" class="tab-pane fade in active" id="attributes">
                                    <div class="col-md-12 text-right">
                                        <input type="button" class="btn btn-primary btn-sm" value="Add Attribute" onclick="addMoreAttributes()" style="margin-top: 10px;margin-bottom: 10px;">
                                    </div>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Attribute</th>
                                                <th>Value</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="add_more_attr">
                                            <tr>














                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" role="tabpanel" class="tab-pane fade in active" id="options">
                                    <div class="col-md-12 text-right">
                                        <input type="button" class="btn btn-primary btn-sm" value="Add Options" onclick="addMoreOptions()" style="margin-top: 10px;margin-bottom: 10px;">
                                    </div>
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>Option</th>
                                            <th>Option Value</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="add_more_option">
















                                        </tbody>
                                    </table>
                                </div>
                                
                            </div>
                                <div class="card-footer text-right">
                                    <button type="submit" class="btn btn-primary" id="submit_btn" style="">Submit</button>
                                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-warning" id="" style="">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
        </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('admin/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dropzone/dist/dropzone.js')); ?>"></script>
    <script type="text/javascript">
        window.onload = function () {
            CKEDITOR.replace('description', {
                
                
            });
        };


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        //Dependent Category
        $(document).ready(function () {
            $('#main-category').on('change',function(e) {
                var cat_id = e.target.value;
                $.ajax({
                    url:"<?php echo e(route('getSubCategories')); ?>",
                    type:"Get",
                    data: {
                        cat_id: cat_id
                    },
                    success:function (data) {
                        $('#sub-category').empty();
                        $.each(data.subcategories,function(index,subcategory){
                            $('#sub-category').append('<option value="'+subcategory.id+'">'+subcategory.name+'</option>');
                        })
                    }
                })
            });

            //Check Product SKU
            $('#product_sku').on('blur',function(e) {
                var sku = e.target.value;
                $.ajax({
                    url:"<?php echo e(route('checkProductSku')); ?>",
                    type:"Get",
                    data: {
                        sku: sku
                    },
                    success:function (data) {
                        if(data.product_sku > 0){
                            $('#sku_span').html(`<p style="color:red">SKU Already exist!</p>`);
                            $(':input[type="submit"]').prop('disabled', true);
                        }else{
                            $('#sku_span').empty();
                            $(':input[type="submit"]').prop('disabled', false);
                        }

                    }
                })
            });

            //Check Product Slug
            $('#product_slug').on('blur',function(e) {
                var slug = e.target.value;
                $.ajax({
                    url:"<?php echo e(route('checkProductSlug')); ?>",
                    type:"Get",
                    data: {
                        slug: slug
                    },
                    success:function (data) {
                        if(data.product_slug > 0){
                            $('#slug_span').html(`<p style="color:red">SLUG Already exist!</p>`);
                                $(':input[type="submit"]').prop('disabled', true);
                        }else{
                            $('#slug_span').empty();
                            $(':input[type="submit"]').prop('disabled', false);
                        }

                    }
                })
            });

            $('#product_sale').on('click',function (e){
                if($('#product_sale').prop('checked') == true){
                    $('#product_sale_percentage').prop('readonly', false);
                }else{
                    $('#product_sale_percentage').prop('readonly', true);
                }
            });

            $('#product_stock').on('click',function (e){
                if($('#product_stock').prop('checked') == true){
                    $('#product_stock_qty').prop('readonly', false);
                }else{
                    $('#product_stock_qty').prop('readonly', true);
                }
            });
        });

        var counter = 1;
        function addMorePictures(){
                counter++;
                $('#add_more').append(`<tr id="row_${counter}">
                                        <td class="col-md-2">
                                            <img src="<?php echo e(asset('admin/images/placeholder.png')); ?>" alt="" id="img_${counter}" style="height: 150px;width: 150px;">
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" name="product_image[]"  id="gallery_${counter}" onchange="PreviewImage('${counter}')" accept="image/*">
                                                    <label class="custom-file-label" for="category-image">Choose file</label>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="button" class="btn btn-danger btn-md" id="removeMoreBtn" onclick="removeImgRow('${counter}')" value="-"/>
                                        </td>
                                    </tr>`);

        }

        function removeImgRow(counter){
            $('#row_'+counter).remove();
        }

        function PreviewImage(counter) {
            var oFReader = new FileReader();
            oFReader.readAsDataURL(document.getElementById('gallery_'+counter).files[0]);

            oFReader.onload = function (oFREvent) {
                document.getElementById('img_'+counter).src = oFREvent.target.result;
            };
        }

        var counter1 = 1;
        function addMoreAttributes(){
            counter1++;
            $('#add_more_attr').append(`<tr id="row_attr_${counter1}">
                                        <td>
                                            <select id="dino-select" class="form-control" name="attribute[]" required>
                                            <option value="">Select Attribute</option>
                                            <?php $__currentLoopData = $attributeGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e($attributeGroup->attribute_group); ?>">
                                            <?php $__currentLoopData = $attributeGroup->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($attributes->id); ?>"><?php echo e($attributes->attribute_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td><input type="text" class="form-control" value="" name="attribute_value[]" required></td>
                                        <td><input type="button" class="btn btn-danger btn-md" value="-" onclick="removeAttrRow(${counter1})" id="add_more_attr_btn"></td></tr>`);
                                        }

        function removeAttrRow(counter){
            $('#row_attr_'+counter).remove();
        }

        //Dependent OPtion
            function getOptionValues(counter,val) {
                var option_id = val;
                if(option_id !== ''){
                    $.ajax({
                        url:"<?php echo e(route('getOptionValues')); ?>",
                        type:"Get",
                        data: {
                            option_id: option_id
                        },
                        success:function (data) {
                            $('#option_value_id_'+counter).empty();
                            $.each(data.OptionValues,function(index,val){
                                $('#option_value_id_'+counter).append('<option value="'+val.id+'">'+val.option_value+'</option>');
                            })
                            }
                        })
                    }
                }

        var counterO = 1;
        function addMoreOptions(){
            counterO++;
            $('#add_more_option').append(`<tr id="row_option_${counterO}"><td>
                                            <select id="option_id_${counterO}" class="form-control" name="option_id[]" onchange="getOptionValues(${counterO},this.value)" required>
                                                <option value="">Select Option</option>
                                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option->id); ?>"><?php echo e($option->option_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            </td>
                                            <td>
                                                <select id="option_value_id_${counterO}" class="form-control" name="option_value_id[]" required></select>
                                            </td>
                                            <td><input type="number" class="form-control" value="" name="option_value_price[]" required></td>
                                            <td><input type="number" class="form-control" value="" name="option_value_qty[]" required></td>
                                            <td><input type="button" class="btn btn-danger btn-md" value="-" onclick="removeOptionRow(${counterO})"></td>
                                        </tr>`);
        }
        function removeOptionRow(counter){
            $('#row_option_'+counter).remove();
        }
        /* Related product functions start */
        var counter2 = 1;
        function addMoreRelatedProducts(){

            $("#add_more_related").append(`<tr id="row_related_${counter2}" class="row_related_prod"><td>
                <select id="related_prod_id_${counter2}" class="form-control related_prod" name="related_prod_id[]" required>
                   <option value="">Select Product</option>
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </td>
                <td><input type="button" class="btn btn-danger btn-md" value="-" onclick="removeRelatedProdRow(${counter2})"></td>
                </tr>`);
            makeRelatedProdArray();
            removeRelatedProdOption(counter2);
            counter2++;
        }

        var relatedProdOptions = [];
        function makeRelatedProdArray() {
            $('.row_related_prod').each(function (i, o) {
                var closestParent = $(this).closest('tr');
                var value = closestParent.find('.related_prod').val();
                if (value != null && value !== '' && relatedProdOptions.includes(value) === false) {
                    relatedProdOptions.push(value);
                }
            });
        }
        makeRelatedProdArray();
        function removeRelatedProdOption(id){
            relatedProdOptions.forEach(function (i, v) {
                $("#related_prod_id_"+id+" option[value='"+i+"']").remove();
            })
        }
        function removeRelatedProdRow(counter){
            var value = $('#row_related_'+counter).find('.related_prod').val();
            if (value != null && value !== '' && relatedProdOptions.includes(value) === true) {
                const index = relatedProdOptions.indexOf(value);
                if (index > -1) {
                    relatedProdOptions.splice(index, 1);
                }
            }
            $('#row_related_'+counter).remove();
        }
        /* Related product functions end */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/admin/product/create.blade.php ENDPATH**/ ?>