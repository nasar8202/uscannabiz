<?php $__env->startSection('title', 'Order Details'); ?>
<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="container">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">

                                <?php if($order->order_status != 'completed'): ?>
                                <div class="col-md-5 float-right">
                                    <label for="">Order Status</label>
                                    <select name="order_status" id="order_status" class="form-control" data-order_id="<?php echo e($order->id); ?>">
                                        <option value="pending" <?php if($order->order_status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                                        <option value="shipped" <?php if($order->order_status == 'paid'): ?> selected <?php endif; ?>>Shipped</option>
                                        <option value="completed" <?php if($order->order_status == 'completed'): ?> selected <?php endif; ?>>Completed</option>
                                        <option value="cancelled" <?php if($order->order_status == 'cancelled'): ?> selected <?php endif; ?>>Cancelled</option>
                                    </select>

                                </div>
                                <?php else: ?>
                                    Completed
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3 class="panel-title text-center"><i class="fa fa-shopping-cart"></i> Order Details</h3>
                                        </div>
                                        <table class="table table-bordered">
                                            <tbody>
                                            <tr>
                                                <td style="width: 2%;">
                                                    <button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Date Added"><i class="fa fa-info-circle fa-fw"></i> </button>
                                                </td>
                                                <td>#<?php echo e($order->order_no); ?></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Date Added"><i class="fa fa-calendar fa-fw"></i></button>
                                                </td>
                                                <td><?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></td>
                                            </tr>
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3 class="panel-title text-center"><i class="fa fa-user"></i> Customer Details</h3>
                                        </div>
                                        <table class="table table-bordered">
                                            <tbody>
                                            <tr>
                                                <td style="width: 1%;">
                                                    <button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Customer"><i class="fa fa-user fa-fw"></i></button>
                                                </td>
                                                <td>
                                                    
                                                        <?php echo e($order->customer_name); ?>

                                                    
                                                </td>
                                            </tr>

                                            <tr>
                                                <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="E-Mail"><i class="fa fa-envelope-o fa-fw"></i></button></td>
                                                <td>
                                                    
                                                        <a href="mailto:<?php echo e($order->customer_email); ?>"><?php echo e($order->customer_email); ?></a>
                                                    

                                                </td>
                                            </tr>
                                            <tr>
                                                <td><button data-toggle="tooltip" title="" class="btn btn-info btn-xs" data-original-title="Telephone"><i class="fa fa-phone fa-fw"></i></button></td>
                                                <td>
                                                    
                                                        <?php echo e($order->phone_no); ?>

                                                    
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <table class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <td style="width: 50%;font-weight: bold" class="text-left">Details</td>
                                           
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td class="text-left">
                                                <strong>Address</strong> : <?php echo e($order->billing_address); ?>

                                                <br>
                                                <strong>City</strong> : <?php echo e($order->billing_city); ?>

                                                <br>
                                            </td>
                                            
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title text-center"> Order Item Details</h3>
                                </div>
                                <div class="table-responsive-sm">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="center">#</th>
                                            <th>Item</th>
                                            <th class="right">Unit Cost</th>
                                            <th class="center">Qty</th>
                                            <th class="right">Total</th>
                                            <?php if(isset($order->broker_price)): ?>
                                            <th class="right">Broker Comission</th>
                                            <?php endif; ?>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $counter = 1;
                                            $subTotal = 0;
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="center"><?php echo e($counter++); ?></td>
                                                <td class="left strong">
                                                    <a href="<?php echo e(URL::to('/').'/shop/'.$orderItems->product->slug); ?>" target="_blank">
                                                        <?php echo e($orderItems->product->product_name); ?>

                                                    </a><br>
                                                   <?php if($orderItems->orderOptions!==null): ?>
                                                    <?php $__empty_2 = true; $__currentLoopData = $orderItems->orderOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <p style="margin-bottom: 0 !important;"><b><?php echo e($option->optionValue['option']['option_name']); ?></b> : <?php echo e($option->optionValue['option_value']); ?></p>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="right">$<?php echo e($orderItems->product_per_price); ?></td>
                                                <td class="center"><?php echo e($orderItems->product_qty); ?></td>
                                                
                                                <td class="right">$<?php echo e($orderItems->product_per_price*$orderItems->product_qty); ?></td>
                                                <?php if(isset($order->broker_price)): ?>
                                                <td class="right">$<?php echo e($order->broker_price); ?></td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php
                                                $subTotal += $orderItems->product_per_price;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4 col-sm-5">
                                    </div>
                                    <div class="col-lg-4 col-sm-5 ml-auto">
                                        <table class="table table-clear">
                                            <tbody>
                                                <tr>
                                                    <?php
                                                    $total_price = $order->orderItems->first()->product_qty*$order->orderItems->first()->product_per_price;
                                                    ?>
                                                    <?php if(isset($order)): ?>
                                                    <td class="left">
                                                        <strong>Subtotal</strong>
                                                    </td>
                                                    <td class="right">$<?php echo e($total_price); ?></td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php if($order->discount > 0): ?>
                                                <tr>
                                                    <td class="left">
                                                        <strong>Discount</strong>
                                                    </td>
                                                    <td class="right">$<?php echo e($order->discount); ?></td>
                                                </tr>
                                            <?php endif; ?>
 

                                            <tr>
                                                <td class="left">
                                                    <strong>Total</strong>
                                                </td>
                                                <?php
                                                $total_price = $order->orderItems->first()->product_qty*$order->orderItems->first()->product_per_price;
                                                ?>
                                                <?php if(isset($order)): ?>
                                                <td class="right">$<?php echo e($total_price+$order->broker_price??''); ?></td>
                                                <?php else: ?>
                                                <td class="right">$<?php echo e($total_price); ?></td>
                                                <?php endif; ?>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).on('change','#order_status',function(){
            let id = $(this).data('order_id');
            let val = $(this).val();

            $.ajax({
                type:"get",
                url:`<?php echo e(url('admin/'.request()->segment(2).'/changeOrderStatus')); ?>/${id}`,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data:{
                    val:val
                },
                success: function (data) {
                    if(data==0) {
                        toastr.error('Exception Here !');
                    }else{
                        toastr.success('Record Status Updated Successfully');
                    }
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/admin/order/show.blade.php ENDPATH**/ ?>