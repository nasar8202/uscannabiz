<?php $__env->startSection('content'); ?>
    <style>
        input {
            text-align: center;
        }
        .quantity{
            width: 80px;
        }
        .removeItem{
            margin-top: 10px;
        }
        .fa fa-trash{
            color:red !important;
        }
    </style>
        <a href="#">Home</a>
        <i class="fa fa-chevron-right breadcrumb-separator"></i>
        <span>Shopping Cart</span>

    <div class="cart-section container">
        <div>
            <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success_message')); ?>

                </div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($cartCollection->count() > 0): ?>

                <h2><?php echo e($cartCollection->count()); ?> item(s) in Shopping Cart</h2>

                <div class="cart-table">
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cart-table-row">
                            <div class="cart-table-row-left">
                                <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->product_image)); ?>" alt="item" class="cart-table-img"></a>
                                <div class="cart-item-details">
                                    <div class="cart-table-item"><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><?php echo e($item->model->product_name); ?></a></div>
                                    <div class="cart-table-description">
                                        <?php if(!empty($item->options)): ?>
                                        <ul>
                                            <?php $__currentLoopData = $item->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oindex=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($oindex !== 'options_id'): ?>
                                                    <li><strong><?php echo e($oindex); ?></strong>: <?php echo e($option); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="cart-table-row-right">

                                <div>





                                    <input type="number" class="quantity" value="<?php echo e($item->qty); ?>" data-id="<?php echo e($item->rowId); ?>" data-productQuantity="<?php echo e($item->model->product_qty); ?>">
                                </div>
                                <div><?php echo e(presentPrice($item->total())); ?></div>
                            </div>
                            <div class="cart-table-actions">
                                <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST" class="removeItem">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <button type="submit" class="cart-options"><i class="fa fa-trash" style="color:red "></i></button>
                                </form>

                                
                                

                                
                                
                            </div>
                        </div> <!-- end cart-table-row -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div> <!-- end cart-table -->

                <div class="cart-totals">
                    <div class="cart-totals-left">
                        Shipping is free because we’re awesome like that. Also because that’s additional stuff I don’t feel like figuring out :).
                    </div>

                    <div class="cart-totals-right">
                        <div>
                            Subtotal <br>
                            <?php if(session()->has('coupon')): ?>
                                Code (<?php echo e(session()->get('coupon')['name']); ?>)
                                <form action="<?php echo e(route('coupon.destroy')); ?>" method="POST" style="display:block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                    <button type="submit" style="font-size:14px;">Remove</button>
                                </form>x
                                <hr>
                                New Subtotal <br>
                            <?php endif; ?>
                            <span class="cart-totals-total">Total</span>
                        </div>
                        <div class="cart-totals-subtotal">
                            <?php echo e(presentPrice(Cart::subtotal())); ?> <br>
                            <?php echo e(presentPrice(Cart::total())); ?>

                        </div>
                    </div>
                </div> <!-- end cart-totals -->

                <div class="cart-buttons">
                    <a href="<?php echo e(route('shop.index')); ?>" class="button">Continue Shopping</a>
                    <a href="<?php echo e(route('checkout.index')); ?>" class="button-primary">Proceed to Checkout</a>
                </div>

            <?php else: ?>
                <h3>No items in Cart!</h3>
                <div class="spacer"></div>
                <a href="<?php echo e(route('shop.index')); ?>" class="button">Continue Shopping</a>
                <div class="spacer"></div>
            <?php endif; ?>

        </div>

    </div> <!-- end cart-section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        (function(){
            $(".quantity").on('change', function (){
                const id = $(this).data('id');
                const productQuantity = $(this).attr('data-productQuantity');
                console.log(productQuantity)
                $.ajax({
                    url: `cart/update/${id}`,
                    type: 'PATCH',
                    data: {
                        quantity: $(this).val(),
                        productQuantity: productQuantity,
                        "_token": $("meta[name='csrf-token']").attr('content')
                    },
                    success: function (){
                        window.location.href = '<?php echo e(route('cart.index')); ?>';
                    },
                    error: function (){
                        window.location.href = '<?php echo e(route('cart.index')); ?>'
                    }
                })
            })
        })();
    </script>

    <!-- Include AlgoliaSearch JS Client and autocomplete.js library -->
    <script src="https://cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js"></script>
    <script src="https://cdn.jsdelivr.net/autocomplete.js/0/autocomplete.min.js"></script>
    <script src="<?php echo e(asset('js/algolia.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/front/cart/index.blade.php ENDPATH**/ ?>