<?php echo e($slot); ?>

<?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>