<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title><?php echo e($setting->company_name); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/jqvmap/jqvmap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/dist/css/adminlte.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/toastr/toastr.min.css')); ?>">
    <?php echo $__env->yieldContent('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('admin/plugins/summernote/summernote-bs4.min.css')); ?>">
     
     <!-- Datatables -->
    <link href="<?php echo e(asset('admin/datatables/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

    <style>
        table.dataTable thead th, table.dataTable thead td{
            border-bottom: 0px;
        }
        table.dataTable.no-footer{
            border-bottom: 1px solid #dee2e6;
        }

        #example1_filter input{
            border-color: #f2f2f2;
        }

 </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__shake" src="<?php echo e(isset($setting->logo) ? URL::asset('uploads/settings/'.$setting->logo) : URL::asset('admin/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTELogo" height="60" width="60">
    </div>
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <!-- Right navbar links -->























    </nav>
    <!-- /.navbar -->
    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="<?php echo e(url('admin/dashboard')); ?>" class="brand-link" style="text-align: center">
            <img class="animation__shake" src="<?php echo e(isset($setting->logo) ? URL::asset('uploads/settings/'.$setting->logo) : URL::asset('admin/dist/img/AdminLTELogo.png')); ?>" alt="Viva Unlimited LLC" style="max-width: 155px;width: 100%;height: auto;">
            
        </a>
        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            
                
                    
                
                
                    
                
            
            <!-- SidebarSearch Form -->
            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <li class="nav-item">
                        <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link <?php echo e(request()->IS('admin/dashboard') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Dashboard
                            </p>
                        </a>
                    </li>

                    <li class="nav-item has-treeview <?php echo e(request()->IS('admin/settings') ? 'menu-is-opening menu-open' : ''); ?>">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-tags fw"></i>
                            <p>
                                Settings
                            </p>
                        </a>
                        <ul class="nav nav-treeview" style="<?php echo e(request()->IS('admin/emailsetting') || request()->IS('admin/paymentgatway') ? 'display:block;' : ''); ?>">
                            <li class="nav-item">
                                <a href="<?php echo e(route('settings')); ?>" class="nav-link <?php echo e(request()->IS('admin/settings') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-cog"></i>
                                    <p>
                                        General Settings
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('paymentgatway')); ?>" class="nav-link <?php echo e(request()->IS('admin/paymentgatway') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-hand-holding-usd"></i>
                                    <p>
                                        Payment Gateways
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('shippingServices')); ?>" class="nav-link <?php echo e(request()->IS('admin/shipping-services') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-hand-holding-usd"></i>
                                    <p>
                                        Shipping Services
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('emailsetting')); ?>" class="nav-link <?php echo e(request()->IS('admin/emailsetting') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-hand-holding-usd"></i>
                                    <p>
                                        Email Setting
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item has-treeview <?php echo e(request()->IS('admin/catalog/attribute-groups') || request()->IS('admin/catalog/attributes') || request()->IS('admin/catalog/options') || request()->IS('admin/catalog/option-values') ||  request()->IS('admin/category') || request()->IS('admin/product') || request()->IS('admin/manufacturer') ||  request()->IS('admin/coupons') || request()->IS('admin/collection') || request()->IS('admin/collectionProducts') || request()->IS('admin/newsletter') || request()->IS('admin/shipping') ? 'menu-is-opening menu-open' : ''); ?>">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-tags fw"></i>
                            <p>
                                Catalog
                            </p>
                        </a>
                        <ul class="nav nav-treeview" style="<?php echo e(request()->IS('admin/catalog/attribute-groups') || request()->IS('admin/catalog/attributes') || request()->IS('admin/catalog/options') || request()->IS('admin/catalog/option-values') ||  request()->IS('admin/category') || request()->IS('admin/product') || request()->IS('admin/manufacturer') ||  request()->IS('admin/coupons') || request()->IS('admin/collection') || request()->IS('admin/collectionProducts') || request()->IS('admin/newsletter') || request()->IS('admin/shipping') ? 'display:block;' : ''); ?>">
                            
                            <li class="nav-item">
                                
                                <a href="<?php echo e(route('attribute.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/catalog/attribute') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Attributes</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                
                                <a href="<?php echo e(route('option.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/catalog/option') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Options</p>
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a href="<?php echo e(route('category')); ?>" class="nav-link <?php echo e(request()->IS('admin/category') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Category</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('product.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/product') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Product</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('manufacturer.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/manufacturer') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Manufacturer</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('coupons.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/coupons') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Coupons</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('collection.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/collection') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Collection</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('collectionProducts.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/collectionProducts') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Collection Products</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('newsletter.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/newsletter') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Newsletter</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('shipping.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/shipping') ? 'active' : ''); ?>">
                                    <i class="nav-icon fa fa-angle-double-right"></i>
                                    <p>Shipping Rate</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('customers.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/customers') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user"></i>
                            <p>Customers</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('order.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/order') ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-shopping-cart" aria-hidden="true"></i>
                            <p>Orders</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('blog.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/blog') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-tags fw"></i>
                            <p>Blog</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('review.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/review') ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-comments"></i>
                            <p>Reviews</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('faq.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/faq') ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-comments"></i>
                            <p>FAQ</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('testimonial.index')); ?>" class="nav-link <?php echo e(request()->IS('admin/testimonial') ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-comments"></i>
                            <p>Testimonial</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('admin/changePassword')); ?>" class="nav-link <?php echo e(request()->IS('admin/changePassword') ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-comments"></i>
                            <p>Change Password</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="dropdown-item nav-link" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                            <i class="nav-icon fas fa-lock"></i> <p><?php echo e(__('Logout')); ?></p>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>

                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <?php echo $__env->yieldContent('section'); ?>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#"><?php echo e($setting->company_name); ?></a>.</strong>
        All rights reserved.
        <div class="float-right d-none d-sm-inline-block">

        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(URL::asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(URL::asset('admin/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(URL::asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>




<!-- JQVMap -->




<!-- daterangepicker -->
<script src="<?php echo e(URL::asset('admin/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(URL::asset('admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(URL::asset('admin/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(URL::asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(URL::asset('admin/dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(URL::asset('admin/dist/js/demo.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(URL::asset('admin/dist/js/pages/dashboard.js')); ?>"></script>

<script src="<?php echo e(URL:: asset('admin/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(URL:: asset('admin/alert.js')); ?>"></script>
<script src="<?php echo e(URL:: asset('admin/plugins/toastr/toastr.min.js')); ?>"></script>


<?php if(session()->has('success')): ?>
    <script type="text/javascript">  toastr.success('<?php echo e(session('success')); ?>');</script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script type="text/javascript"> toastr.error('<?php echo e(session('error')); ?>');</script>
<?php endif; ?>
<script>

</script>


<script src="<?php echo e(asset('admin/datatables/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('admin/datatables/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecm\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>