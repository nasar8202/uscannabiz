<?php $__env->startSection('title', (isset($content->id) ?  'Edit' : 'Add').' Category'); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Category Form</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Category Form</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger alert-block">

                <strong><?php echo e($error); ?></strong>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-8">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Category</h3>
                            </div>
                            <form class="category-form" method="post" action="<?php echo e(!empty($content->id)?url('admin/category-edit/'.$content->id):route('admin.add-category')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <?php if(Session::has('msg')): ?>
                                        <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Main Category</label>
                                        <select class="form-control <?php if(Session::has('err')): ?> is-invalid <?php endif; ?>" name="main-category" id="main-category">
                                            <option value="0">Select Category</option>
                                            <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e((!empty($content->parent_id)&&$content->parent_id==$category->id)||old('main-category')==$category->id?'selected':''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name ?? ''); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if(Session::has('err')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e(Session::get('err')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Category Name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" value="<?php echo e($content->name?? old('name')); ?>" placeholder="Category" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="category">Description</label>
                                        <textarea class="form-control" name="description" id="description" placeholder="Description" ><?php echo e($content->description?? old('description')); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="category">Meta Title</label>
                                        <input type="text" class="form-control" name="meta-title" id="meta-title"  value="<?php echo e($content->meta_tag_title?? old('meta-title')); ?>" placeholder="Meta Title">
                                    </div>
                                    <div class="form-group">
                                        <label for="category">Meta Description</label>
                                        <textarea class="form-control" name="meta-description" id="meta-description" placeholder="Meta Description"><?php echo e($content->meta_tag_description?? old('meta-description')); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="category">Meta Keywords</label>
                                        <textarea class="form-control" name="meta-keywords" id="meta-keywords"  placeholder="Meta Keywords"><?php echo e($content->meta_tag_keywords?? old('meta-keywords')); ?></textarea>
                                    </div>
                                    <div class="row">

                                        <div class="col-md-9">
                                            <div class="form-group">
                                                <label for="exampleInputFile">Category Image</label>
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" accept="image/png, image/jpeg, image/jpg" name="file" id="category-image">
                                                        <label class="custom-file-label" for="category-image">Choose file</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3" >
                                            <img src="<?php echo e(asset(isset($content->category_image) ?'uploads/category/'.$content->category_image : 'admin/images/placeholder.png')); ?>" alt="" id="img_0" style="height: 150px;width: 150px;">
                                        </div>

                                    </div>

                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary btn-md">Submit</button>
                                    <a href="<?php echo e(route('category')); ?>" class="btn btn-warning btn-md">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/admin/category/add-category.blade.php ENDPATH**/ ?>