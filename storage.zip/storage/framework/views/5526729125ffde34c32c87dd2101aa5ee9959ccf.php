<?php $__env->startSection('section'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <?php if(auth()->user()->role_id == 3): ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        Vender Dashboard
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php else: ?>
    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            
                            <h3><?php echo e($data['orders']); ?></h3>
                            <p>Total Orders</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="<?php echo e(route('order.index')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
    <?php if(auth()->user()->role_id == 1): ?>
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo e($data['products']); ?></h3>
                            <p>All Approved Products</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars"></i>
                        </div>
                        <a href="<?php echo e(route('product.index')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-primary">
                        <div class="inner">
                            <h3><?php echo e($data['vendors']); ?></h3>
                            <p>All Approved Vendors</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add"></i>
                        </div>
                        <a href="<?php echo e(route('Vendor.index')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo e($data['brokers']); ?></h3>
                            <p>All Approved Brokers</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add"></i>
                        </div>
                        <a href="<?php echo e(route('customers.index')); ?>" class="small-box-footer">More info <i
                                class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <?php endif; ?>
                <!-- ./col -->

                <!-- ./col -->
            </div>
            
            <div class="row mt-4 mb-3">
    <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <i class="nav-icon fa fa-shopping-cart" aria-hidden="true"></i> &nbsp; <span
                                style="font-size:20px; font-weight: bold;">Latest Orders</span>
                        </div>
                        <div class="card-body">
                            <?php if(Auth::user()->role_id == 1): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order Id</th>
                                        <th>Customer</th>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <?php else: ?>
                                        <th>Status</th>
                                        <?php endif; ?>
                                        <th>Order Date</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__empty_1 = true; $__currentLoopData = $data['latestOrders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestOrders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $latestOrders_data= App\Models\Order::where('id',$latestOrders->order_id)->first();
                                        ?>
                                    <?php if(Auth::user()->role_id == 4): ?>
                                    <tr>
                                    <?php else: ?>
                                    <tr onclick="window.location='order/<?php echo e($latestOrders->id); ?>'" style='cursor: pointer;'>
                                    <?php endif; ?>
                                        <td> <?php echo e($latestOrders->order_no??'Not Accepted'); ?> </td>
                                        <td> <?php echo e($latestOrders->customer_name??'Anonymous'); ?> </td>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <?php else: ?>
                                        <td>
                                            <?php if($latestOrders->order_status == 'pending'): ?>
                                            <span class="badge badge-secondary">Pending</span>
                                            <?php elseif($latestOrders->order_status == 'cancelled'): ?>
                                            <span class="badge badge-danger">Cancelled</span>
                                            <?php elseif($latestOrders->order_status == 'completed'): ?>
                                            <span class="badge badge-success">Completed</span>
                                            <?php elseif($latestOrders->order_status == 'shipped'): ?>
                                            <span class="badge badge-info">Shipped</span>
                                            <?php endif; ?>
                                            
                                        </td>
                                        <?php endif; ?>
                                        <td> <?php echo e(date('d-M-Y',strtotime($latestOrders->created_at))); ?> </td>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <td> <?php echo e($latestOrders_data ? '$'.$latestOrders_data->total_amount : 'Broker Amount Pending'); ?> </td>
                                        <?php else: ?>
                                        <td> $<?php echo e($latestOrders->total_amount); ?> </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center"> Not Yet Latest Orders </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php else: ?>

                                <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order Id</th>
                                        <th>Customer</th>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <?php else: ?>
                                        <th>Status</th>
                                        <?php endif; ?>
                                        <th>Order Date</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__empty_1 = true; $__currentLoopData = $data['latestOrders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestOrders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $latestOrders_data= App\Models\Order::where('id',$latestOrders->order_id)->first();
                                        ?>
                                    <?php if(Auth::user()->role_id == 4): ?>
                                    <tr>
                                    <?php else: ?>
                                    <tr onclick="window.location='order/<?php echo e($latestOrders->id); ?>'" style='cursor: pointer;'>
                                    <?php endif; ?>
                                        <td> <?php echo e($latestOrders_data->order_no??'Not Accepted'); ?> </td>
                                        <td> <?php echo e($latestOrders->full_name??'Anonymous'); ?> </td>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <?php else: ?>
                                        <td>
                                            <?php if($latestOrders->order_status == 'pending'): ?>
                                            <span class="badge badge-secondary">Pending</span>
                                            <?php elseif($latestOrders->order_status == 'cancelled'): ?>
                                            <span class="badge badge-danger">Cancelled</span>
                                            <?php elseif($latestOrders->order_status == 'completed'): ?>
                                            <span class="badge badge-success">Completed</span>
                                            <?php elseif($latestOrders->order_status == 'shipped'): ?>
                                            <span class="badge badge-info">Shipped</span>
                                            <?php endif; ?>
                                            
                                        </td>
                                        <?php endif; ?>
                                        <td> <?php echo e(date('d-M-Y',strtotime($latestOrders->created_at))); ?> </td>
                                        <?php if(Auth::user()->role_id == 4): ?>
                                        <td> <?php echo e($latestOrders_data ? '$'.$latestOrders_data->total_amount : 'Broker Amount Pending'); ?> </td>
                                        <?php else: ?>
                                        <td> $<?php echo e($latestOrders->total_amount); ?> </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center"> Not Yet Latest Orders </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            

            
            
            </div>
            
            <!-- /.row -->
            <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
    </section>
    <?php endif; ?>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>