<?php echo $__env->make('front.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    .et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et_pb_text_0_tb_footer.et_pb_text,.et_pb_text_5_tb_footer.et_pb_text,.et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_1_tb_footer{margin-bottom:15px!important}.et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et_pb_text_4_tb_footer h4,.et_pb_text_2_tb_footer h4,.et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_3_tb_footer,.et_pb_text_2_tb_footer,.et_pb_text_4_tb_footer{margin-bottom:20px!important}.et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}.et_pb_section_0.et_pb_section{padding-top:0px}.et_pb_row_0.et_pb_row{padding-top:0px!important;padding-top:0px}.et_pb_text_0 h2{font-weight:600;font-size:14px;color:#FFFFFF!important;text-align:center}.et_pb_text_0{background-color:#0D4400;border-radius:31px 31px 31px 31px;overflow:hidden;padding-top:15px!important;padding-bottom:5px!important;margin-top:30px!important;margin-right:10px!important;margin-bottom:20px!important}.et_pb_sidebar_0.et_pb_widget_area{border-top-color:RGBA(255,255,255,0);border-right-color:RGBA(255,255,255,0);border-left-color:RGBA(255,255,255,0)}.et_pb_sidebar_0{padding-top:10px}.et_pb_text_1 h1{font-weight:600;font-size:39px;color:#FFFFFF!important}.et_pb_text_1{background-image:url(assets/uploads/2022/03/shutterstock_1877216707.jpg);padding-top:100px!important;padding-right:30px!important;padding-bottom:100px!important;padding-left:30px!important;margin-bottom:50px!important}.et_pb_code_0{padding-right:15px;padding-left:15px}.et_pb_text_2 h3{font-weight:600;font-size:20px;color:#000000!important;text-align:center}.et_pb_text_2{padding-top:15px!important}.et_pb_column_0{border-width:1px;border-color:rgba(112,112,112,0.49);padding-right:15px;padding-left:15px}.et_pb_column_1{border-right-width:1px;border-right-color:rgba(112,112,112,0.49)}@media  only screen and (max-width:980px){.et_pb_sidebar_0.et_pb_widget_area{border-top-color:RGBA(255,255,255,0);border-right-color:RGBA(255,255,255,0);border-left-color:RGBA(255,255,255,0)}.et_pb_text_1 h1{font-size:30px}.et_pb_text_1{background-position:right 0px center;background-color:initial}.et_pb_text_2 h3{font-size:18px}.et_pb_column_1{border-right-width:0px;border-right-color:rgba(112,112,112,0.49)}}@media  only screen and (max-width:767px){.et_pb_sidebar_0.et_pb_widget_area{border-top-color:RGBA(255,255,255,0);border-right-color:RGBA(255,255,255,0);border-left-color:RGBA(255,255,255,0)}.et_pb_text_1 h1{font-size:20px}.et_pb_text_2 h3{font-size:16px}.et_pb_column_1{border-right-width:0px;border-right-color:rgba(112,112,112,0.49)}}
 </style>
 <div id="main-content">
    <article id="post-34" class="post-34 page type-page status-publish hentry">
       <div class="entry-content">
          <div class="et-l et-l--post">
             <div class="et_builder_inner_content et_pb_gutters3">
                <div class="et_pb_section et_pb_section_0 sec-1 et_section_regular">
                   <div class="et_pb_row et_pb_row_0 et_pb_gutters1">
                      <div class="et_pb_with_border et_pb_column_1_5 et_pb_column et_pb_column_0  et_pb_css_mix_blend_mode_passthrough">
                         <div class="et_pb_module et_pb_text et_pb_text_0  et_pb_text_align_left et_pb_bg_layout_light">
                            <div class="et_pb_text_inner">
                               <h2>All Categories</h2>
                            </div>
                         </div>
                         <div class="et_pb_with_border et_pb_module et_pb_sidebar_0 et_pb_widget_area clearfix et_pb_widget_area_left et_pb_bg_layout_light">
                            <div id="block-9" class="et_pb_widget widget_block">
                               <div class="wp-container-62b3603e50735 wp-block-group">
                                  <div class="wp-block-group__inner-container">
                                     <div data-block-name="woocommerce/product-categories" data-has-empty="true" class="wp-block-woocommerce-product-categories wc-block-product-categories is-list ">
                                        <ul class="wc-block-product-categories-list wc-block-product-categories-list--depth-0">
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/uncategorized/">Uncategorized</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">1</span><span class="screen-reader-text">1 product</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">
                                              <a href="product-category/flowers/">Flowers</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">6</span><span class="screen-reader-text">6 products</span></span>
                                              <ul class="wc-block-product-categories-list wc-block-product-categories-list--depth-1">
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/exotic/">Exotic</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/indoor/">Indoor</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/glass-house/">Glass House</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/light-dep/">Light Dep</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/hoop-house/">Hoop House</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/out-door/">Out Door</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/flowers/all/">All</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                              </ul>
                                           </li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/distillate/">Distillate</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">6</span><span class="screen-reader-text">6 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/trim-fresh-frozen/">Trim + Fresh Frozen</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">4</span><span class="screen-reader-text">4 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/clones-teens/">Clones + Teens</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">7</span><span class="screen-reader-text">7 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">
                                              <a href="product-category/concentrates/">Concentrates</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">7</span><span class="screen-reader-text">7 products</span></span>
                                              <ul class="wc-block-product-categories-list wc-block-product-categories-list--depth-1">
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/badder/">Badder</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/crumble/">Crumble</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">3</span><span class="screen-reader-text">3 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/diamonds/">Diamonds</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/hash/">Hash</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/rosin-resin/">Rosin + Resin</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/sauce/">Sauce</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/sugar/">Sugar</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/wax/">Wax</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                                 <li class="wc-block-product-categories-list-item">					<a href="product-category/concentrates/all-concentrates/">All</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                              </ul>
                                           </li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/prerolls/">PreRolls</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">3</span><span class="screen-reader-text">3 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/cartridges-vapes/">Cartridges + Vapes</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">3</span><span class="screen-reader-text">3 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/edibles/">Edibles</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/white-label/">White Label</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">3</span><span class="screen-reader-text">3 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/business-licenses-for-sales/">Business &amp; Licenses for Sales</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                           <li class="wc-block-product-categories-list-item">					<a href="product-category/equipment-for-sale/">Equipment For Sale</a>				<span class="wc-block-product-categories-list-item-count"><span aria-hidden="true">2</span><span class="screen-reader-text">2 products</span></span>									</li>
                                        </ul>
                                     </div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="et_pb_with_border et_pb_column_3_5 et_pb_column et_pb_column_1  et_pb_css_mix_blend_mode_passthrough">
                         <div class="et_pb_module et_pb_text et_pb_text_1 f-text  et_pb_text_align_left et_pb_bg_layout_light">
                            <div class="et_pb_text_inner">
                               <h1>Featured Products</h1>
                            </div>
                         </div>
                         <div class="et_pb_module et_pb_code et_pb_code_0 main-cate">
                            <div class="et_pb_code_inner">
                               <div class="woocommerce columns-4">
                                  <ul class="products columns-4">
                                     <li class="product-category product first">
                                        <a href="product-category/flowers/">
                                           <img src="assets/uploads/2022/03/Mask-Group-1-300x300.png" alt="Flowers" width="300" height="300" srcset="assets/uploads/2022/03/Mask-Group-1-300x300.png 300w, assets/uploads/2022/03/Mask-Group-1-150x150.png 150w, assets/uploads/2022/03/Mask-Group-1-100x100.png 100w" sizes="(max-width: 300px) 100vw, 300px">
                                           <h2 class="woocommerce-loop-category__title">
                                              Flowers <mark class="count">(6)</mark>
                                           </h2>
                                        </a>
                                     </li>
                                     <li class="product-category product">
                                        <a href="product-category/distillate/">
                                           <img src="assets/uploads/2022/03/Mask-Group-2-300x300.png" alt="Distillate" width="300" height="300" srcset="assets/uploads/2022/03/Mask-Group-2-300x300.png 300w, assets/uploads/2022/03/Mask-Group-2-150x150.png 150w, assets/uploads/2022/03/Mask-Group-2-100x100.png 100w" sizes="(max-width: 300px) 100vw, 300px">
                                           <h2 class="woocommerce-loop-category__title">
                                              Distillate <mark class="count">(6)</mark>
                                           </h2>
                                        </a>
                                     </li>
                                     <li class="product-category product">
                                        <a href="product-category/clones-teens/">
                                           <img src="assets/uploads/2022/03/Mask-Group-3-300x300.png" alt="Clones + Teens" width="300" height="300" srcset="assets/uploads/2022/03/Mask-Group-3-300x300.png 300w, assets/uploads/2022/03/Mask-Group-3-150x150.png 150w, assets/uploads/2022/03/Mask-Group-3-100x100.png 100w" sizes="(max-width: 300px) 100vw, 300px">
                                           <h2 class="woocommerce-loop-category__title">
                                              Clones + Teens <mark class="count">(7)</mark>
                                           </h2>
                                        </a>
                                     </li>
                                     <li class="product-category product last">
                                        <a href="product-category/trim-fresh-frozen/">
                                           <img src="assets/uploads/2022/03/Mask-Group-4-300x300.png" alt="Trim + Fresh Frozen" width="300" height="300" srcset="assets/uploads/2022/03/Mask-Group-4-300x300.png 300w, assets/uploads/2022/03/Mask-Group-4-150x150.png 150w, assets/uploads/2022/03/Mask-Group-4-100x100.png 100w" sizes="(max-width: 300px) 100vw, 300px">
                                           <h2 class="woocommerce-loop-category__title">
                                              Trim + Fresh Frozen <mark class="count">(4)</mark>
                                           </h2>
                                        </a>
                                     </li>
                                  </ul>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="et_pb_column et_pb_column_1_5 et_pb_column_2  et_pb_css_mix_blend_mode_passthrough et-last-child">
                         <div class="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light">
                            <div class="et_pb_text_inner">
                               <h3>Recently Viewed Products</h3>
                            </div>
                         </div>
                         <div class="et_pb_module et_pb_code et_pb_code_1 recent-pro">
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </article>
 </div>




<?php echo $__env->make('front.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xamp7\htdocs\app\resources\views/front/index.blade.php ENDPATH**/ ?>