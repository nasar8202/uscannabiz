
<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et_pb_text_0_tb_footer.et_pb_text,.et_pb_text_5_tb_footer.et_pb_text,.et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_1_tb_footer{margin-bottom:15px!important}.et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et_pb_text_4_tb_footer h4,.et_pb_text_2_tb_footer h4,.et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_3_tb_footer,.et_pb_text_2_tb_footer,.et_pb_text_4_tb_footer{margin-bottom:20px!important}.et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}
</style>
<div class="page-template-default page theme-Divi et-tb-has-template et-tb-has-footer woocommerce-js et_button_no_icon et_pb_button_helper_class et_fixed_nav et_show_nav et_secondary_nav_enabled et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_header_style_left et_cover_background et_pb_gutter windows et_pb_gutters3 et_right_sidebar et_divi_theme et-db et_full_width_page et_no_sidebar dokan-dashboard dokan-theme-Divi customize-support chrome">
	<div id="main-content">
	   <div class="container">
	      <div id="content-area" class="clearfix">
	         <div id="left-area">
	            <article id="post-7" class="post-7 page type-page status-publish hentry">
	               <h1 class="entry-title main_title">Dashboard</h1>
				   <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('success')); ?>

                                        </div>
										<?php endif; ?>
	               <div class="entry-content">
	                  <div class="dokan-dashboard-wrap">
						<div class="dokan-dash-sidebar">
	                        <div id="dokan-navigation" aria-label="Menu">
	                           <label id="mobile-menu-icon" for="toggle-mobile-menu" aria-label="Menu">☰</label><input id="toggle-mobile-menu" type="checkbox">
	                           
                               <ul class="dokan-dashboard-menu">
								<li class="active dashboard"><a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
								<li class="products"><a href="<?php echo e(route('product')); ?>"><i class="fas fa-briefcase"></i> Products</a></li>
								<li class="orders"><a href="<?php echo e(route('vendor_order')); ?>"><i class="fas fa-shopping-cart"></i> Orders</a></li>
								<li class="orders"><a href="<?php echo e(route('show_brokers')); ?>"><i class="fas fa-shopping-cart"></i> Broker</a></li>
	                              
	                              <li class="settings"><a href="<?php echo e(Route('editVendor')); ?>"><i class="fas fa-cog"></i> Settings <i class="fas fa-angle-right pull-right"></i></a></li>
	                              
	                           </ul>
	                        </div>
	                     </div>
	                     <div class="dokan-dashboard-content dokan-orders-content">
						   <article class="dokan-orders-area">
						      <ul class="list-inline order-statuses-filter">
						         <li class="active">
						            <a >
						            All (<?php echo e($countBroker??0); ?>)
						            </a>
						         </li>
						         
						      </ul>
							  <?php if(isset($show_data)): ?>
							  <td data-title="S.no" class="column-thumb">
								 <?php echo e($show_data); ?>

							  </td>
							  <?php else: ?>
							  <?php if(!$brokers->isEmpty()): ?>
							  <?php if(Session::has('success')): ?>
									<div class="alert alert-success text-center"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('success'); ?></em></div>
								<?php endif; ?>
							  <?php if(Session::has('error')): ?>
									<div class="alert alert-success text-center"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('error'); ?></em></div>
								<?php endif; ?>
								<form method="GET" action="<?php echo e(Route('assignbroker')); ?>">
								<table class="dokan-table dokan-table-striped product-listing-table dokan-inline-editable-table" id="dokan-product-list-table">
								<thead>
									
								   <tr>
									<?php if(isset($brokers) && isset($customer_condition) && $customer_condition == $brokers->first()->id): ?>
									<?php else: ?>
									<th>Select</th>
									<?php endif; ?>
									  <th>S.No</th>
									  <th>Name</th>
									  <th>Email</th>
									  
									  <th>Phone Number</th>
									  <th>City</th>
									  <th>State</th>
									  <th>Country</th>
									  <th>Address</th>
									  <?php if(isset($brokers) && isset($customer_condition) && $customer_condition == $brokers->first()->id): ?>
									  <th>Status</th>
									  <th>Broker Percentage</th>
									  <?php else: ?>
										<?php endif; ?>
									  
								   </tr>
								</thead>
								<tbody>
									<?php
										$counter = 1;
									?>
								 <?php $__currentLoopData = $brokers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $broker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								   <tr class="">
									<?php if(isset($customer_condition) && $customer_condition == $broker->id): ?>
									<?php else: ?>
									<th class="dokan-product-select check-column">
										<label for="cb-select-432"></label>
										<input class="cb-select-items dokan-checkbox" type="checkbox" data-product-name="Testing Products" name="id[]" value="<?php echo e($broker->id); ?>">
									</th>
									<?php endif; ?>
									  <td data-title="S.no" class="column-thumb">
										 <?php echo e($counter++); ?>

									  </td>
									  <td data-title="name" class="column-primary">
										<?php echo e($broker->first_name); ?> <?php echo e($broker->last_name); ?>

									  </td>
									  <td data-title="email" class="column-primary">
										<?php echo e($broker->email); ?>

									  </td>
									  <td data-title="phone" class="column-primary">
										<?php echo e($broker->phone_no); ?>

									  </td>
									  <td data-title="city" class="column-primary">
										<?php echo e($broker->city); ?>

									  </td>
									  <td data-title="state" class="column-primary">
										<?php echo e($broker->state); ?>

									  </td>
									  <td data-title="country" class="column-primary">
										<?php echo e($broker->country); ?>

									  </td>
									  <td data-title="address" class="column-primary">
										<?php echo e($broker->address); ?>

									  </td>
									  <?php if(isset($customer_condition) && $customer_condition == $broker->id): ?>
									  <td data-title="address" class="column-primary">
										  This Broker Assigned by admin
										</td>
										<td data-title="address" class="column-primary">
											<?php echo e($broker->broker_percentage); ?>%
										</td>
										<?php else: ?>
									  <?php endif; ?>
									  <td data-title="address" class="column-primary">
										
									  <td class="diviader"></td>
								   </tr>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							 </table>
							  <?php else: ?>
							  <?php
								$counter;
							?>
						      <div class="dokan-error">
						         No Brokers found
						      </div>
							  <?php endif; ?>
							  
						   </article>
						   <?php if(isset($customer_condition) && $customer_condition == $broker->id): ?>
						   <?php else: ?>
						   <span class="dokan-add-product-link">
							   <button type="submit" class="dokan-btn dokan-btn-theme dokan-add-new-product float-right">Send Request</button>
							   
							</span>
							<?php endif; ?>
						</form>
						<?php endif; ?>
							<br>
						</div>
	                  </div>
	               </div>
	            </article>
	         </div>
	         <div id="sidebar">
	         </div>
	      </div>
	   </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/vendor/brokers/index.blade.php ENDPATH**/ ?>