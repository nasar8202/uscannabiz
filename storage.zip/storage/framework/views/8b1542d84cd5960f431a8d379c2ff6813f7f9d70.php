<footer>
    <div class="footer-content container col-md-12">
        <div class="col-md-4">
            <div class="made-with">Made with <i class="fa fa-heart heart"></i></div>
        </div>
        <div class="col-md-4">
            <ul>
                <li>Follow Me:</li>
                <li><a href=""><i class="fa Follow Me:"></i></a></li>
                <li><a href="#"><i class="fa fa-globe"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                <li><a href="#"><i class="fa fa-github"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            </ul>
            <ul>
                <li>
                    <a href="<?php echo e(route('contactUs')); ?>">
                        Contact Us
                    </a>
                </li>
            </ul>
        </div>


        <div class="col-md-4">
            <div class="ftrList newsltr mb-1">
                <h4>Subscribe to Newsletter</h4>
            </div>
            <form class="newsletterForm form-group" onsubmit="return false;">
                <input class="form-control" id="email_newsletter" type="email" placeholder="your email address" aria-label="Email" required/>
                <button id="newsletterSubmit" type="submit" class="btn btn-secondary mt-2">Subscribe</button>
            </form>
        </div>
    </div> <!-- end footer-content -->
</footer>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"  crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
        base_url = "<?php echo e(url('/')); ?>";
    })
</script>
<script src="<?php echo e(URL:: asset('js/app_script.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $("#newsletterSubmit").on('click', function () {
            var email = $("#email_newsletter").val();
            var $this = $(this);
            $(this).prop('disabled', true);
            $('.newsletterForm > .alert').remove();
            $.ajax({
                url: '<?php echo e(route("newsletter")); ?>',
                type: 'post',
                data: {"_token": "<?php echo e(csrf_token()); ?>", "email": email},
                dataType: 'json',
                success: function(json) {
                    if(json['status'] == true){
                        $("#email_newsletter").val('');
                        $this.parents('.newsletterForm').prepend('<div class="alert alert-success" style="padding:10px;margin-bottom:10px;">'+json['success']+'</div>');
                    }
                    else{
                        $this.prop('disabled', false);
                        $this.parents('.newsletterForm').prepend('<div class="alert alert-danger" style="padding:10px;margin-bottom:10px;">'+json['error']+'</div>');
                    }
                }
            });
        })
    })
</script>
<?php /**PATH C:\xampp\htdocs\ecm\resources\views/front/partials/footer.blade.php ENDPATH**/ ?>