<header>
    <div class="top-nav container">
        <div class="top-nav-left">
            <div class="logo"><a href="/">Ecommerce</a></div>
            <?php if(! (request()->is('checkout') || request()->is('guestCheckout'))): ?>
                <ul>
                    <li>
                        <a href="<?php echo e(route('shop.index')); ?>">
                            Shop
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            About
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contactUs')); ?>">
                            Contact Us
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Blog
                        </a>
                    </li>
                    <?php if(Auth::check()): ?>
                    <li>
                        <a href="<?php echo e(route('shop.view_wishlist')); ?>">
                            Wishlist
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
        <div class="top-nav-right">
            <?php if(! (request()->is('checkout') || request()->is('guestCheckout'))): ?>
                <ul>
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="logn" href="<?php echo e(route('login')); ?>">Login</a>
                        <a class="logn" href="<?php echo e(route('register')); ?>">Register</a>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(url('user/dashboard')); ?>">Dashboard</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item nav-link" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <p><?php echo e(__('Logout')); ?></p>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('cart.index')); ?>">Cart
                            <?php if(Cart::instance('default')->count() > 0): ?>
                                <span class="cart-count"><span><?php echo e(Cart::instance('default')->count()); ?></span></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div> <!-- end top-nav -->
</header>

<?php /**PATH C:\xamp7\htdocs\app\resources\views/front/partials/nav.blade.php ENDPATH**/ ?>