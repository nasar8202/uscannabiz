<?php echo e($slot); ?>

<?php /**PATH C:\xamp7\htdocs\app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>