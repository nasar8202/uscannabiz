

<?php $__env->startSection('title', 'Wishlist'); ?>


<?php $__env->startSection('content'); ?>
<section class="banner banner2">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Wishlist</h2>
            </div>
        </div>
    </div>
</section>
<section class="shopPage">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="row">
                            <?php if($products->count() > 0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="shopEyelashes">
                                    <a href="<?php echo e(route('shop.show', $product->product->slug)); ?>">
                                        <figure><img src="<?php echo e(productImage($product->product->product_image)); ?>" class="img-fluid" alt="img"></figure>
                                        <h2><?php echo e($product->product->product_name); ?></h2>
                                    </a>
                                    <a href="<?php echo e(route('shop.show', $product->product->slug)); ?>" class="addCart"><span><img src="<?php echo e(asset('front/images/payment.png')); ?>" class="img-fluid" alt="img"></span>Add to cart</a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/front/wishlist.blade.php ENDPATH**/ ?>