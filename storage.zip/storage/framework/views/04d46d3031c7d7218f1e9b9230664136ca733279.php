<?php $__env->startSection('title', 'Products'); ?>


<?php $__env->startSection('content'); ?>
<style id="et-builder-module-design-179-cached-inline-styles">.et-db #et-boc .et-l .et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et-db #et-boc .et-l .et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et-db #et-boc .et-l .et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et-db #et-boc .et-l .et_pb_text_0_tb_footer.et_pb_text,.et-db #et-boc .et-l .et_pb_text_5_tb_footer.et_pb_text,.et-db #et-boc .et-l .et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et-db #et-boc .et-l .et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_1_tb_footer{margin-bottom:15px!important}.et-db #et-boc .et-l .et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et-db #et-boc .et-l .et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et-db #et-boc .et-l .et_pb_text_4_tb_footer h4,.et-db #et-boc .et-l .et_pb_text_2_tb_footer h4,.et-db #et-boc .et-l .et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_3_tb_footer,.et-db #et-boc .et-l .et_pb_text_2_tb_footer,.et-db #et-boc .et-l .et_pb_text_4_tb_footer{margin-bottom:20px!important}.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et-db #et-boc .et-l .et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et-db #et-boc .et-l .et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et-db #et-boc .et-l .et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}</style>
<div class="container">
    <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success_message')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<div class="archive tax-product_cat theme-Divi et-tb-has-template et-tb-has-footer woocommerce woocommerce-page woocommerce-js et_button_no_icon et_pb_button_helper_class et_fixed_nav et_show_nav et_secondary_nav_enabled et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_header_style_left et_cover_background et_pb_gutter windows et_pb_gutters3 et_left_sidebar et_divi_theme et-db dokan-theme-Divi customize-support chrome">
<div id="main-content">
  <div class="container">
     <div id="content-area" class="clearfix">
        <div id="left-area">
           <nav class="woocommerce-breadcrumb"><a href="">Home</a>&nbsp;&#47;&nbsp;<?php echo e($title); ?></nav>
           <header class="woocommerce-products-header">
              <h1 class="woocommerce-products-header__title page-title"><?php echo e($title); ?></h1>
           </header>
           <div class="woocommerce-notices-wrapper"></div>
           <p class="woocommerce-result-count">
              Showing all <?php echo e($productCount?? 0); ?> results
           </p>
           
           <ul class="products columns-3" style="display:flex;flex-wrap:wrap;">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <li class="product type-product post-179 status-publish first instock product_cat-business-licenses-for-sales product_cat-cartridges-vapes product_cat-clones-teens product_cat-concentrates product_cat-distillate product_cat-edibles product_cat-equipment-for-sale product_cat-flowers product_cat-prerolls product_cat-trim-fresh-frozen product_cat-white-label has-post-thumbnail shipping-taxable purchasable product-type-simple">
                <a href="<?php echo e(route('shop.showProduct', $product->slug)); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                    <span class="et_shop_image"><img width="51" height="53" src="<?php echo e(productImage($product->product_image)); ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy"><span class="et_overlay"></span></span>
                    <h2 class="woocommerce-loop-product__title"><?php echo e($product->product_name); ?></h2>
                    <?php if(Auth::check()): ?>
                    <?php
                    $check_broker = Auth::user()->role_id;
                ?>
                <?php if($check_broker == 4): ?>
                
                <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span><?php echo e($product->product_current_price); ?></bdi></span></span>
                <?php endif; ?>
                <?php endif; ?>
               </a>
                <?php if(Auth::check()): ?>
                        <a href="javascript:void(0)" data-product="<?php echo e($product->id); ?>" <?php if(isset($product->whishlist)): ?> data-wishlist='<?php echo e($product->whishlist->id); ?>' <?php endif; ?> data-customer="<?php echo e(Auth::id() ?? 0); ?>" class="grey <?php if(!isset($product->whishlist)): ?> add_to_wishlist <?php else: ?> remove_to_wishlist wishlist-added <?php endif; ?>">
                                                        <i class="fas fa-heart"></i>
                                                    </a>
                                                    <?php endif; ?>
            </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class='categoryResult' style="text-align: left">Category has No Products found</div>
                <?php endif; ?>
           </ul>
        </div>
        <div id="sidebar">
           <div id="block-2" class="et_pb_widget widget_block widget_search">
              <form role="search" method="get" action="/" class="wp-block-search__button-outside wp-block-search__text-button wp-block-search">
                 <label for="wp-block-search__input-1" class="wp-block-search__label">Search</label>
                 <div class="wp-block-search__inside-wrapper ">
                    <input type="search" id="wp-block-search__input-1" class="wp-block-search__input " name="s" value="" placeholder="" required><button type="submit" class="wp-block-search__button  ">Search</button>
                 </div>
              </form>
           </div>
           <div id="block-3" class="et_pb_widget widget_block">
              <div class="wp-container-62b360594849d wp-block-group">
                 <div class="wp-block-group__inner-container">
                    <h2>Recent Posts</h2>
                    <ul class="wp-block-latest-posts__list wp-block-latest-posts">
                       <li><a href="/2022/03/22/hello-world/">Hello world!</a></li>
                    </ul>
                 </div>
              </div>
           </div>
           <div id="block-4" class="et_pb_widget widget_block">
              <div class="wp-container-62b3605948af9 wp-block-group">
                 <div class="wp-block-group__inner-container">
                    <h2>Recent Comments</h2>
                    <ol class="wp-block-latest-comments">
                       <li class="wp-block-latest-comments__comment">
                          <article>
                             <footer class="wp-block-latest-comments__comment-meta"><a class="wp-block-latest-comments__comment-author" href="https://wordpress.org/">A WordPress Commenter</a> on <a class="wp-block-latest-comments__comment-link" href="/2022/03/22/hello-world/#comment-1">Hello world!</a></footer>
                          </article>
                       </li>
                    </ol>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </div>
</div>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <!-- Include AlgoliaSearch JS Client and autocomplete.js library -->
    <script src="https://cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js"></script>
    <script src="https://cdn.jsdelivr.net/autocomplete.js/0/autocomplete.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webprojectmockup/public_html/custom/uscannabiz/resources/views/front/shop/show.blade.php ENDPATH**/ ?>