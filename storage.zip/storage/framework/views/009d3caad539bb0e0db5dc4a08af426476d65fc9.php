
<?php $__env->startSection('title', $product->product_name ?? 'Product'); ?>
<?php $__env->startSection('page_css'); ?>
    <style>
        th {
            background-color: #f7f7f7;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">

                    <div class="col-sm-6 offset-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Product</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Product Detail</h3>
                            </div>

                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Product</th>
                                        <td colspan="5"><?php echo e($product->product_name??''); ?></td>
                                    </tr>

                                    <tr>
                                        <th>Category</th>
                                        <td colspan="2"><?php echo e($product->category->name??''); ?></td>
                                        <th>Sub-Category</th>
                                        <td colspan="2"><?php echo e($product->sub_category->name??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Slug</th>
                                        <td colspan="2"><?php echo e($product->slug??''); ?></td>
                                        <th>SKU</th>
                                        <td colspan="2"><?php echo e($product->sku??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Current Price</th>
                                        <td colspan="2"><?php echo e($product->product_current_price??''); ?></td>
                                        <th>Product Sale</th>
                                        <td colspan="2"><?php echo e($product->product_sale??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Product Sale %</th>
                                        <td colspan="2"><?php echo e($product->product_sale_percentage??''); ?></td>
                                        <th>Product Stock</th>
                                        <td colspan="2"><?php echo e($product->product_stock??''); ?></td>
                                       
                                    </tr>
                                    <tr>
                                        <th>Meta Tag Title</th>
                                        <td colspan="2"><?php echo e($product->product_meta_data->meta_tag_title??''); ?></td>
                                        <th>Product Qty</th>
                                        <td><?php echo e($product->product_qty??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td colspan="5"> <?php echo $product->description??''; ?></td>
                                    </tr>

                                    <tr>
                                        <th>Meta Tag Keywords</th>
                                        <td colspan="5"><?php echo e($product->product_meta_data->meta_tag_keywords??''); ?></td>
                                    
                                    </tr>
                                    <tr>
                                        <th>Meta Tag Description</th>
                                        <td colspan="5"><?php echo e($product->product_meta_data->meta_tag_description??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Attributes</th>
                                        <td colspan="5">
                                            <?php $__currentLoopData = $product->products_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products_attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($products_attribute->attribute->attribute_name??''); ?> - <?php echo e($products_attribute->value??''); ?>

                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Options (Price - Qty)</th>
                                        <td colspan="5">
                                            <?php $__currentLoopData = $product->products_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products_options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $products_options->option_val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($products_options->option->option_name??''); ?> - <?php echo e($option_value->option_value??''); ?> - <?php echo e($products_options->price); ?> - <?php echo e($products_options->qty); ?>

                                                <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Width</th>
                                        <td colspan="2"><?php echo e($product->width??''); ?></td>
                                        <th>Height</th>
                                        <td colspan="2"><?php echo e($product->height??''); ?></td>

                                    </tr>
                                    <tr>
                                        <th>Length</th>
                                        <td colspan="2"><?php echo e($product->length??''); ?></td>
                                        <th>Weight</th>
                                        <td colspan="2"><?php echo e($product->weight??''); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Image</th>
                                        <td colspan="5">
                                            <img src="<?php echo e(productImage(@$product->product_image)); ?>" width="100px" height="100px">
                                            <?php $__currentLoopData = $product->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e(productImage(@$product_image->product_images)); ?>" width="100px" height="100px">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Manufacturer</th>
                                        <td colspan="5">
                                            <?php echo e($product->manufacturer->name ?? ''); ?>

                                        </td>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>

                            </div>
                            <!-- /.card-body -->
                        </div>

                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>

                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/product/show.blade.php ENDPATH**/ ?>