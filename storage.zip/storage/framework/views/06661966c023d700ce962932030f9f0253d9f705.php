<?php $__env->startSection('title', 'Vendor'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et_pb_text_0_tb_footer.et_pb_text,.et_pb_text_5_tb_footer.et_pb_text,.et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_1_tb_footer{margin-bottom:15px!important}.et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et_pb_text_4_tb_footer h4,.et_pb_text_2_tb_footer h4,.et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et_pb_text_3_tb_footer,.et_pb_text_2_tb_footer,.et_pb_text_4_tb_footer{margin-bottom:20px!important}.et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}
</style>

<div class="page-template-default page theme-Divi et-tb-has-template et-tb-has-footer woocommerce-js et_button_no_icon et_pb_button_helper_class et_fixed_nav et_show_nav et_secondary_nav_enabled et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_header_style_left et_cover_background et_pb_gutter windows et_pb_gutters3 et_right_sidebar et_divi_theme et-db et_full_width_page et_no_sidebar dokan-dashboard dokan-theme-Divi customize-support chrome">
	<div id="main-content">
	   <div class="container">
	      <div id="content-area" class="clearfix">
	         <div id="left-area">
	            <article id="post-7" class="post-7 page type-page status-publish hentry">
	               <h1 class="entry-title main_title">Dashboard</h1>
	               <div class="entry-content">
	                  <div class="dokan-dashboard-wrap">
	                	<div class="dokan-dash-sidebar">
	                        <div id="dokan-navigation" aria-label="Menu">
	                           <label id="mobile-menu-icon" for="toggle-mobile-menu" aria-label="Menu">☰</label><input id="toggle-mobile-menu" type="checkbox">
	                           <ul class="dokan-dashboard-menu">
								<li class="active dashboard"><a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
								<li class="products"><a href="<?php echo e(route('product')); ?>"><i class="fas fa-briefcase"></i> Products</a></li>
								<li class="orders"><a href="<?php echo e(route('vendor_order')); ?>"><i class="fas fa-shopping-cart"></i> Orders</a></li>
								<li class="orders"><a href="<?php echo e(route('show_brokers')); ?>"><i class="fas fa-shopping-cart"></i> Broker</a></li>
	                              <li class="withdraw"><a href="<?php echo e(route('show_brokers_yajra')); ?>""><i class="fas fa-upload"></i> Broker Yajra</a></li>
	                              <li class="settings"><a href="<?php echo e(Route('editVendor')); ?>"><i class="fas fa-cog"></i> Settings <i class="fas fa-angle-right pull-right"></i></a></li>
	                              
	                           </ul>
	                        </div>
	                     </div>
	                     <div class="dokan-dashboard-content">
	                        <article class="dashboard-content-area">
	                           <div class="dokan-w6 dokan-dash-left">
	                              <div class="dashboard-widget big-counter">
	                                 <ul class="list-inline">
	                                    <li>
	                                       <div class="title">Sales</div>
	                                       <div class="count"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>0.00</span></div>
	                                    </li>
	                                    <li>
	                                       <div class="title">Earning</div>
	                                       <div class="count"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>0.00</span></div>
	                                    </li>
	                                    <li>
	                                       <div class="title">Pageview</div>
	                                       <div class="count"><?php echo e($productViewed->view ?? 0); ?></div>

	                                    </li>
	                                    <li>
	                                       <div class="title">Order</div>
	                                       <div class="count">
	                                          <?php echo e($orderCount ?? 0); ?>

	                                       </div>
	                                    </li>
	                                 </ul>
	                              </div>
	                              <!-- .big-counter -->
	                              <div class="dashboard-widget orders">
	                                 <div class="widget-title"><i class="fas fa-shopping-cart"></i> Orders</div>
	                                 <div class="content-half-part">
	                                    <ul class="list-unstyled list-count">
	                                       <li>
	                                          <a >
	                                          <span class="title">Total</span> <span class="count"><?php echo e($orderCount ?? 0); ?></span>
	                                          </a>
	                                       </li>
	                                       <li>
	                                          <a  style="color: #73a724">
	                                          <span class="title">Completed</span> <span class="count"><?php echo e($orderCompletedCount??0); ?></span>
	                                          </a>
	                                       </li>
	                                       <li>
	                                          <a  style="color: #999">
	                                          <span class="title">Pending</span> <span class="count"><?php echo e($orderPendingCount??0); ?></span>
	                                          </a>
	                                       </li>
	                                       
	                                       <li>
	                                          <a href="orders/?order_status=wc-cancelled" style="color: #d54e21">
	                                          <span class="title">Cancelled</span> <span class="count"><?php echo e($orderCancelledCount??0); ?></span>
	                                          </a>
	                                       </li>
	                                       
	                                       
	                                    </ul>
	                                 </div>
	                                 <div class="content-half-part">
	                                    <canvas id="order-stats" width="199" height="199" style="display: block; box-sizing: border-box; height: 199px; width: 199px;"></canvas>
	                                 </div>
	                              </div>
	                              <!-- .orders -->
	                              <script type="text/javascript">
	                                 jQuery(function($) {
	                                     var order_stats = [0,0,0,0,0,0];
	                                     var colors = ["#73a724","#999","#21759b","#d54e21","#e6db55","#f0ad4e"];
	                                     var labels = ["Completed","Pending","Processing","Cancelled","Refunded","On Hold"];

	                                     var ctx = $("#order-stats").get(0).getContext("2d");
	                                     var donn = new Chart(ctx, {
	                                         type: 'doughnut',
	                                         data: {
	                                             datasets: [{
	                                                 data: order_stats,
	                                                 backgroundColor: colors
	                                             }],
	                                             labels: labels,
	                                         },
	                                         options: {
	                                             plugins: {
	                                                 legend: false
	                                             }
	                                         }
	                                     });
	                                 });
	                              </script>
	                              <div class="dashboard-widget products">
	                                 <div class="widget-title">
	                                    <i class="fas fa-briefcase" aria-hidden="true"></i> Products
	                                    <span class="pull-right">
	                                    <a href="new-product/">+ Add new product</a>
	                                    </span>
	                                 </div>
	                                 <ul class="list-unstyled list-count">
	                                    <li>
	                                       
	                                       <span class="title">Total</span> <span class="count"><?php echo e($productCount ?? 0); ?></span>
	                                       
	                                    </li>
	                                    
	                                 </ul>
	                              </div>
	                              <!-- .products -->
	                           </div>
	                           <!-- .col-md-6 -->
	                           
	                        </article>
	                        <!-- .dashboard-content-area -->
	                     </div>
	                     <!-- .dokan-dashboard-content -->
	                  </div>
	                  <!-- .dokan-dashboard-wrap -->
	               </div>
	            </article>
	         </div>
	         <div id="sidebar">
	         </div>
	      </div>
	   </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>