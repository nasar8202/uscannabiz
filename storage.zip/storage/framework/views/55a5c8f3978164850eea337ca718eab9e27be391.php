
<?php $__env->startSection('title', 'Payment Gateways'); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Payment Gateways Form</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Payment Gateways</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Payment Gateways</h3>
                            </div>
                            <form class="category-form" method="post"  action="<?php echo e(route('paymentgatway')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                             <div class="card-body">
                                <div class="row">
                                   <div class="col-md-12">                                    
                                        <div class="form-group">
                                        
                                            
                                        <div id="accordion">
                                            <div class="card">
                                              <div class="card-header bg-dark" id="headingOne">
                                                <h5 class="mb-0">
                                                  <div class="btn btn-link text-white text-left" style="width:100%;" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    Paypal
                                                  </div>
                                                </h5>
                                              </div>
                                          
                                              <div id="collapseOne" class="collapse border border-dark" aria-labelledby="headingOne" data-parent="#accordion">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Select Environment:
                                                        </div>
                                                        <div class="col-md-9"> 
                                                             <input type="radio" name="paypal_env" required id="paypal_env_live"  <?php if($content->paypal_env == "Live"): ?> checked <?php endif; ?> value="Live"> Live &nbsp;
                                                            <input type="radio" name="paypal_env" required id="paypal_env_testing"  <?php if($content->paypal_env == "Testing"): ?> checked <?php endif; ?> value="Testing"> Testing
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Client ID:
                                                        </div>
                                                        <div class="col-md-9"><input type="text" name="paypal_client_id" id="paypal_client_id" required class="form-control" value="<?php echo e($content->paypal_client_id??''); ?>"></div>
                                                    </div>
                                                    <br/>
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Secret Key:
                                                        </div>
                                                        <div class="col-md-9"><input type="text" name="paypal_secret_key" id="paypal_secret_key" required  class="form-control" value="<?php echo e($content->paypal_secret_key??''); ?>" ></div>
                                                    </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="card">
                                              <div class="card-header bg-dark" id="headingTwo">
                                                <h5 class="mb-0">
                                                  <div class="btn btn-link collapsed text-white text-left" style="width:100%;" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                    Stripe 
                                                  </div>
                                                </h5>
                                              </div>
                                              <div id="collapseTwo" class="collapse border border-dark" aria-labelledby="headingTwo" data-parent="#accordion">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Select Environment:
                                                        </div>
                                                        <div class="col-md-9"> 
                                                             <input type="radio" name="stripe_env" <?php if($content->stripe_env == "Live"): ?> checked <?php endif; ?> required id="stripe_env_live" value="Live"> Live &nbsp;
                                                            <input type="radio" name="stripe_env" <?php if($content->stripe_env == "Testing"): ?> checked <?php endif; ?> required id="stripe_env_testing" value="Testing"> Testing
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Publishable Key:
                                                        </div>
                                                        <div class="col-md-9"><input type="text" name="stripe_publishable_key"  id="stripe_publishable_key" required class="form-control" value="<?php echo e($content->stripe_publishable_key??''); ?>"></div>
                                                    </div>
                                                    <br/>
                                                    <div class="row">
                                                        <div class="col-md-3"> 
                                                            Secret Key:
                                                        </div>
                                                        <div class="col-md-9"><input type="text" name="stripe_secret_key" id="stripe_secret_key" required  class="form-control" value="<?php echo e($content->stripe_secret_key??''); ?>"></div>
                                                    </div>
                                                </div>
                                              </div>
                                            </div>
                                       
                                       <div class="card">
                                        <div class="card-header bg-dark" id="headingThree">
                                          <h5 class="mb-0">
                                            <div class="btn btn-link collapsed text-white text-left" style="width:100%;" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                              Authorize.net 
                                            </div>
                                          </h5>
                                        </div>
                                        <div id="collapseThree" class="collapse border border-dark" aria-labelledby="headingThree" data-parent="#accordion">
                                          <div class="card-body">
                                              <div class="row">
                                                  <div class="col-md-3"> 
                                                      Select Environment:
                                                  </div>
                                                  <div class="col-md-9"> 
                                                       <input type="radio" name="authorize_env" <?php if($content->authorize_env == "Live"): ?> checked <?php endif; ?> required id="authorize_env_live" value="Live"> Live &nbsp;
                                                      <input type="radio" name="authorize_env" <?php if($content->authorize_env == "Testing"): ?> checked <?php endif; ?> required id="authorize_env_testing" value="Testing"> Testing
                                                  </div>
                                              </div>
                                              <br>
                                              <div class="row">
                                                  <div class="col-md-3"> 
                                                     Merchant Login ID:
                                                  </div>
                                                  <div class="col-md-9"><input type="text" name="authorize_merchant_login_id"  id="authorize_merchant_login_id" required class="form-control" value="<?php echo e($content->authorize_merchant_login_id??''); ?>"></div>
                                              </div>
                                              <br/>
                                              <div class="row">
                                                  <div class="col-md-3"> 
                                                    Merchant Transaction Key:
                                                  </div>
                                                  <div class="col-md-9"><input type="text" name="authorize_merchant_transaction_key" id="authorize_merchant_transaction_key" required  class="form-control" value="<?php echo e($content->authorize_merchant_transaction_key??''); ?>"></div>
                                              </div>
                                          </div>
                                        </div>
                                      </div>
                                 
                                          </div>
                                        
                                        
                                        </div>
                                    </div>
                                    
                                </div>

                                </div>

                             </div>

                             <div class="card-footer float-right">
                                <button type="submit" onclick="validateInputs()" class="btn btn-primary">Submit</button>
                            </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('admin/custom_js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<script>

    function validateInputs(){
         //paypal
     var  paypal_env_live=document.getElementById("paypal_env_live").value;
     var  paypal_env_testing=document.getElementById("paypal_env_live").value;
     var paypal_client_id=document.getElementById("paypal_client_id").value;
     var paypal_secret_key=document.getElementById("paypal_secret_key").value;
     var paypal_collapseOne=document.getElementById("collapseOne");
         //stripe
     var  stripe_env_live=document.getElementById("paypal_env_live").value;
     var  stripe_env_testing=document.getElementById("paypal_env_live").value;
     var stripe_publishable_key=document.getElementById("stripe_publishable_key").value;
     var stripe_secret_key=document.getElementById("stripe_secret_key").value;     
     var stripe_collapseTwo=document.getElementById("collapseTwo");
         //authorize.net
     var  authorize_env_live=document.getElementById("authorize_env_live").value;
     var  authorize_env_testing=document.getElementById("authorize_env_testing").value;
     var authorize_merchant_login_id=document.getElementById("authorize_merchant_login_id").value;
     var authorize_merchant_transaction_key=document.getElementById("authorize_merchant_transaction_key").value;     
     var authorize_collapseThree=document.getElementById("collapseThree");


        if(paypal_env_live!="checked" || paypal_env_testing!="checked"){ 
                if(paypal_client_id=="" ||  paypal_secret_key==""){
                    paypal_collapseOne.setAttribute("class", "show");
                }
        }
        if(stripe_env_live!="checked" || stripe_env_testing!="checked"){ 
               if(stripe_publishable_key=="" || stripe_secret_key==""){
                    stripe_collapseTwo.setAttribute("class", "show");
                }
            }
        if(authorize_env_live!="checked" || authorize_env_testing!="checked"){ 
               if(authorize_merchant_login_id=="" || authorize_merchant_transaction_key==""){
                authorize_collapseThree.setAttribute("class", "show");
                }
            }


}//end validateInputs

</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/paymentGateway/edit.blade.php ENDPATH**/ ?>