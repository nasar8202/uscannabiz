
<?php $__env->startSection('title', 'Customer Detail'); ?>
<?php $__env->startSection('page_css'); ?>
<link rel="stylesheet" href="//cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<style>
    th {
        background-color: #f7f7f7;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">


            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <!-- /.card -->
                    <?php if($user->role_id == 2): ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Customer Details</h3>
                        </div>

                       
                        <!-- /.card-header -->
                        <div class="card-body">

                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>First Name</th>
                                    <td><?php echo e($content->first_name ?? ''); ?></td>
                                    <th>Last Name</th>
                                    <td><?php echo e($content->last_name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($content->email ?? ''); ?></td>
                                    <th>Phone</th>
                                    <td><?php echo e($content->phone_no ?? ''); ?></td>
                                </tr>
                                
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <?php elseif($user->role_id == 3): ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Vendor Details</h3>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body">

                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>First Name</th>
                                    <td><?php echo e($content->first_name ?? ''); ?></td>
                                    <th>Last Name</th>
                                    <td><?php echo e($content->last_name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($content->email ?? ''); ?></td>
                                    <th>Phone</th>
                                    <td><?php echo e($content->phone_no ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>City</th>
                                    <td><?php echo e($content->city ?? ''); ?></td>
                                    <th>State</th>
                                    <td><?php echo e($content->state ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Country</th>
                                    <td><?php echo e($content->country ?? ''); ?></td>
                                    <th>Address</th>
                                    <td><?php echo e($content->address ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Store Name</th>
                                    <td><?php echo e($vendor_stores->store_name ?? ''); ?></td>
                                    <th>Store Url</th>
                                    <td><?php echo e($vendor_stores->store_url ?? ''); ?></td>
                                </tr>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <?php elseif($user->role_id == 4): ?>

                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Broker Details</h3>
                        </div>

                       
                        <!-- /.card-header -->
                        <div class="card-body">

                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>First Name</th>
                                    <td><?php echo e($content->first_name ?? ''); ?></td>
                                    <th>Last Name</th>
                                    <td><?php echo e($content->last_name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($content->email ?? ''); ?></td>
                                    <th>Phone</th>
                                    <td><?php echo e($content->phone_no ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>City</th>
                                    <td><?php echo e($content->city ?? ''); ?></td>
                                    <th>State</th>
                                    <td><?php echo e($content->state ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Country</th>
                                    <td><?php echo e($content->country ?? ''); ?></td>
                                    <th>Address</th>
                                    <td><?php echo e($content->address ?? ''); ?></td>
                                </tr>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <?php endif; ?>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            
        </div>
        <!-- /.container-fluid -->
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>