
<?php $__env->startSection('title', 'Admin Setting'); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Email Setting</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Email Setting</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Site Settings Email</h3>
                            </div>
                            <form class="category-form" method="post"  action="<?php echo e(route('emailsetting')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                    <div class="col-md-6">
                                        
                                        <div class="form-group">
                                            <label for="name">Mail Domain</label>
                                            <input type="text" class="form-control" name="mail_domain" id="mail_domain"
                                                   value="<?php echo e($content->mail_domain ?? ''); ?>" placeholder="site title" required>
                                        </div>


                                  
                                        <div class="form-group">
                                            <label for="name">MAIL ENCRYPTION</label>
                                            <select name="ssl" id="ssl" class="form-control" >
                                                <option value="ssl" <?php if(@$content->ssl == 'ssl'): ?> <?php echo e("selected"); ?> <?php endif; ?> >ssl</option>
                                                <option value="tls" <?php if(@$content->ssl == 'tls'): ?> <?php echo e("selected"); ?> <?php endif; ?>>tls</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Username</label>
                                            <input type="text" class="form-control" name="username" id="name"
                                                   value="<?php echo e($content->username??''); ?>" placeholder="username"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Mail From Name</label>
                                            <input type="text" class="form-control" name="from_address" id="name"
                                                   value="<?php echo e($content->from_address??''); ?>" placeholder="from_address"
                                                   required>
                                        </div>
                                        

                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label for="name">Mail Host</label>
                                            <input type="text" class="form-control" name="mail_host" id="name"
                                                   value="<?php echo e($content->mail_host??''); ?>" placeholder="mail_host"
                                                   required>
                                        </div>
                                        
                                      
                                        <div class="form-group">
                                            <label for="name">Mail Port</label>
                                            <input type="text" class="form-control" name="mail_port" id="name"
                                                   value="<?php echo e($content->mail_port??''); ?>" placeholder="mail_port"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Password</label>
                                            <input type="text" class="form-control" name="password" id="name"
                                                   value="<?php echo e($content->password??''); ?>" placeholder="password"
                                                   required>
                                        </div>
                                       
                                    <!-- /.card-body -->
                                        
                                    </div>
                                    <div class="card-footer float-right">
                                        <input type="submit" onclick="validateinputs()" class="btn btn-primary" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/emailsetting/edit.blade.php ENDPATH**/ ?>