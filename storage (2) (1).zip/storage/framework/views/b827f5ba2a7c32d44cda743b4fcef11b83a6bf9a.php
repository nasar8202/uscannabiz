<?php $__env->startSection('title', 'Add Product Form'); ?>
<?php $__env->startSection('content'); ?>
<style id="et-builder-module-design-179-cached-inline-styles">.et-db #et-boc .et-l .et_pb_section_0_tb_footer.et_pb_section{padding-bottom:20px;background-color:#0D4400!important}.et-db #et-boc .et-l .et_pb_row_0_tb_footer.et_pb_row{padding-top:0px!important;padding-bottom:0px!important;padding-top:0px;padding-bottom:0px}.et-db #et-boc .et-l .et_pb_image_0_tb_footer{margin-bottom:20px!important;text-align:left;margin-left:0}.et-db #et-boc .et-l .et_pb_text_0_tb_footer.et_pb_text,.et-db #et-boc .et-l .et_pb_text_5_tb_footer.et_pb_text,.et-db #et-boc .et-l .et_pb_text_7_tb_footer.et_pb_text{color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_0_tb_footer{font-size:18px;margin-bottom:30px!important}.et-db #et-boc .et-l .et_pb_text_1_tb_footer h5{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif;font-weight:600;font-size:25px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_1_tb_footer{margin-bottom:15px!important}.et-db #et-boc .et-l .et_pb_social_media_follow_0_tb_footer li a.icon:before{font-size:20px;line-height:40px;height:40px;width:40px}.et-db #et-boc .et-l .et_pb_social_media_follow_0_tb_footer li a.icon{height:40px;width:40px}.et-db #et-boc .et-l .et_pb_text_4_tb_footer h4,.et-db #et-boc .et-l .et_pb_text_2_tb_footer h4,.et-db #et-boc .et-l .et_pb_text_3_tb_footer h4{font-weight:600;font-size:25px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_text_3_tb_footer,.et-db #et-boc .et-l .et_pb_text_2_tb_footer,.et-db #et-boc .et-l .et_pb_text_4_tb_footer{margin-bottom:20px!important}.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area li,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area li:before,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area a,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area li,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area li:before,.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area a{font-size:18px;color:#FFFFFF!important}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_text_5_tb_footer{line-height:1.4em;font-size:18px;line-height:1.4em;margin-bottom:30px!important}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:0px!important;padding-top:0px}.et-db #et-boc .et-l .et_pb_text_7_tb_footer{font-size:18px}@media  only screen and (max-width:980px){.et-db #et-boc .et-l .et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}@media  only screen and (max-width:767px){.et-db #et-boc .et-l .et_pb_image_0_tb_footer .et_pb_image_wrap img{width:auto}.et-db #et-boc .et-l .et_pb_sidebar_0_tb_footer.et_pb_widget_area,.et-db #et-boc .et-l .et_pb_sidebar_1_tb_footer.et_pb_widget_area{border-right-color:RGBA(255,255,255,0)}.et-db #et-boc .et-l .et_pb_row_1_tb_footer.et_pb_row{padding-top:20px!important;padding-top:20px!important}}</style>
<div class="archive tax-product_cat theme-Divi et-tb-has-template et-tb-has-footer woocommerce woocommerce-page woocommerce-js et_button_no_icon et_pb_button_helper_class et_fixed_nav et_show_nav et_secondary_nav_enabled et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_header_style_left et_cover_background et_pb_gutter windows et_pb_gutters3 et_left_sidebar et_divi_theme et-db dokan-theme-Divi customize-support chrome">
   <div class="page-template-default page theme-Divi et-tb-has-template et-tb-has-footer woocommerce-js et_button_no_icon et_pb_button_helper_class et_fixed_nav et_show_nav et_secondary_nav_enabled et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_header_style_left et_cover_background et_pb_gutter windows et_pb_gutters3 et_right_sidebar et_divi_theme et-db et_full_width_page et_no_sidebar dokan-dashboard dokan-theme-Divi customize-support chrome">
      <div id="main-content">
         <div class="container">
            <div id="content-area" class="clearfix">
               <div id="left-area">
                  <article id="post-7" class="post-7 page type-page status-publish hentry">
                     <h1 class="entry-title main_title">Settings</h1>
                     <div class="entry-content">
                        <div class="dokan-dashboard-wrap">
                           <div class="dokan-dash-sidebar">
                              <div id="dokan-navigation" aria-label="Menu">
                                 <label id="mobile-menu-icon" for="toggle-mobile-menu" aria-label="Menu">☰</label><input id="toggle-mobile-menu" type="checkbox">
                                 
                                 <ul class="dokan-dashboard-menu">
                                    <li class="dashboard <?php echo e(Request::route()->getName() == 'dashboard_vendor' ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard_vendor')); ?>"><i class="fas fa-tachometer"></i> Dashboard</a></li>
                                    <li class="products <?php echo e(Request::route()->getName() == 'product' ? 'active' : ''); ?>"><a href="<?php echo e(route('product')); ?>"><i class="fas fa-briefcase"></i> Products</a></li>
                                    <li class="orders <?php echo e(Request::route()->getName() == 'vendor_order' ? 'active' : ''); ?>"><a href="<?php echo e(route('vendor_order')); ?>"><i class="fas fa-shopping-cart"></i> Orders</a></li>
                                    
                                    <li class="orders <?php echo e(Request::route()->getName() == 'show_inventory' ? 'active' : ''); ?>"><a href="<?php echo e(route('show_inventory')); ?>"><i class="fas fa-shopping-cart"></i> Inventory</a></li>
                                    
                                             <li class="settings <?php echo e(Request::route()->getName() == 'editVendor' ? 'active' : ''); ?>"><a href="<?php echo e(Route('editVendor')); ?>"><i class="fas fa-cog"></i> Settings <i class="fas fa-angle-right pull-right"></i></a></li>
                                             
                                          </ul>
                              </div>
                           </div>
                           <div class="dokan-dashboard-content editAccount-Details">
                              <article class="dashboard-content-area woocommerce edit-account-wrap">
                                 <h1 class="entry-title">Edit Account Details</h1>
                                 <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <?php if(session()->has('error')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(session()->get('error')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <?php if($errors->any()): ?>
                                        <div class="alert alert-danger alert-block">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <strong><?php echo e($error); ?></strong>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                 <form class="edit-account" action="<?php echo e(route('updateVendor',$user->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <p class="form-row form-row-first">
                                       <label for="account_first_name">First name <span class="required">*</span></label>
                                       <input type="text" class="input-text" name="first_name" value="<?php echo e($customer->first_name); ?>" id="account_first_name" value="">


                                    </p>
                                    <p class="form-row form-row-first">
                                       <label for="account_first_name">Last name <span class="required">*</span></label>
                                       <input type="text" class="input-text" name="last_name" value="<?php echo e($customer->last_name); ?>" id="account_first_name" value="">


                                    </p>

                                    <div class="clear"></div>
                                    <p class="form-row form-row-wide">
                                       <label for="account_email">Email address <span class="required">*</span></label>
                                       <input type="email" class="input-text" name="account_email" id="account_email" value="<?php echo e($user->email); ?>">
                                    </p>
                                    <br>
                                    <p>
                                       <input type="hidden" id="_wpnonce" name="_wpnonce" value="ebd582eb76"><input type="hidden" name="_wp_http_referer" value="/wp/uscannabiz/dashboard/edit-account/">

                                       <button type="submit" class="dokan-btn dokan-btn-danger dokan-btn-theme" name="dokan_save_account_details" >Save Changes</button>
                                       <input type="hidden" name="action" value="dokan_save_account_details">
                                    </p>
                                 </form>
                                    <form class="edit-account" action="<?php echo e(route('updateVendorPass',$user->id)); ?>" method="post">
                                       <?php echo e(csrf_field()); ?>

                                       <fieldset>
                                       <legend>Password Change</legend>
                                       <br>
                                       <p class="form-row form-row-wide">
                                          <label for="password_current">Current Password (leave blank to leave unchanged)</label>
                                          <input type="password" class="input-text" name="password_current" id="password_current">
                                       </p>
                                       <p class="form-row form-row-wide">
                                          <label for="password_1">New Password (leave blank to leave unchanged)</label>
                                          <input type="password" class="input-text" name="password" id="password">
                                       </p>
                                       <p class="form-row form-row-wide">
                                          <label for="password_2">Confirm New Password</label>
                                          <input type="password" class="input-text" name="confirm_password" id="confirm_password">
                                       </p>
                                    </fieldset>
                                    <div class="clear"></div>
                                    <p>
                                       <input type="hidden" id="_wpnonce" name="_wpnonce" value="ebd582eb76"><input type="hidden" name="_wp_http_referer" value="/wp/uscannabiz/dashboard/edit-account/">

                                       <button type="submit" class="dokan-btn dokan-btn-danger dokan-btn-theme" name="dokan_save_account_details" >Save Password Changes</button>
                                       <input type="hidden" name="action" value="dokan_save_account_details">
                                    </p>
                                    <br>
                                 </form>
                              </article>
                              <!-- .dashboard-content-area -->
                           </div>
                           <!-- .dokan-dashboard-content -->
                        </div>
                        <!-- .dokan-dashboard-wrap -->
                     </div>
                  </article>
               </div>
               <div id="sidebar">
               </div>
            </div>
         </div>
      </div>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/vendor/product/editVendor.blade.php ENDPATH**/ ?>