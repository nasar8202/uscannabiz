
<?php $__env->startSection('title', 'Send Newsletter'); ?>
<?php $__env->startSection('section'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Send Newsletter Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Send Newsletter Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Send Newsletter</h3>
                        </div>
                        <form class="category-form" method="post" action="<?php echo e(route('sendnewsletteremail')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <?php if(Session::has('msg')): ?>
                                    <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label for="subject">Subject *</label>
                                    <input type="text" class="form-control" name="subject" id="subject"
                                        value="<?php echo e(old('subject')); ?>" required placeholder="Subject">
                                </div>
                                <div class="form-group">
                                    <label for="newslettermessagebody">Message *</label><br />
                                    <textarea class="form-control" name="message" id="message"
                                        required>
                                        <?php echo e(old('message')); ?>

                                    </textarea>
                                    <span style="color:red;"><?php echo $errors->first('message', '<p class="help-block">:message</p>'); ?></span>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary btn-md">Submit</button>
                                <a href="<?php echo e(route('newsletter.index')); ?>" class="btn btn-warning btn-md">Cancel</a>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dropzone/dist/dropzone.js')); ?>"></script>
<script type="text/javascript">
    window.onload = function() {
        CKEDITOR.replace('message', {
            
            
        });
    };

   function validateTextarea(){
       var txt=document.getElementById("message").value;

       if(txt==""){
           alert(txt);
       }
   } 

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/newsletter/sendnewsletter.blade.php ENDPATH**/ ?>