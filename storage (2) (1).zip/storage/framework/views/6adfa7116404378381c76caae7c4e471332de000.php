
<?php $__env->startSection('title', 'Admin Setting'); ?>
<?php $__env->startSection('section'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Setting Form</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Setting</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Site Settings</h3>
                            </div>
                            <form class="category-form" method="post"  action="<?php echo e(route('settings')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <label for="name">Site Title</label>
                                            <input type="text" class="form-control" name="site_title" id="name"
                                                   value="<?php echo e($content->site_title??''); ?>" placeholder="site title"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Company Name</label>
                                            <input type="text" class="form-control" name="company_name" id="name"
                                                   value="<?php echo e($content->company_name??''); ?>" placeholder="company_name"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Shipping Rate</label>
                                            <select name="shipping_rate" id="shipping_rate" class="form-control" >
                                                <option value="">Select Shipping Rate</option>
                                                <?php $__currentLoopData = $shippingRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shippingRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($shippingRate->id); ?>" <?php if($content->shipping_rate == $shippingRate->id): ?> selected <?php endif; ?>><?php echo e($shippingRate->rate); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Email</label>
                                            <input type="email" class="form-control" name="email" id="email"
                                                   value="<?php echo e($content->email??''); ?>" placeholder="email"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Phone No 1 </label>
                                            <input type="number" class="form-control" name="phone_no_1" id="name"
                                                   value="<?php echo e($content->phone_no_1??''); ?>" placeholder="Phone Number 1"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Phone No 2 </label>
                                            <input type="number" class="form-control" name="phone_no_2" id="name"
                                                   value="<?php echo e($content->phone_no_2??''); ?>" placeholder="Phone Number 2">
                                        </div>
                                    
                                   <div class="form-group">
                                             
                                            
                                        
                                        
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name">Address</label>
                                            <input type="text" class="form-control" name="address" id="address"
                                                   value="<?php echo e($content->address??''); ?>" placeholder="address"
                                                   required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Facebook</label>
                                            <input type="url" class="form-control" name="facebook" id="facebook"
                                                   value="<?php echo e($content->facebook??''); ?>" placeholder="facebook"
                                                   >
                                        </div>
                                        <div class="form-group">
                                            <label for="name">Twitter</label>
                                            <input type="text" class="form-control" name="tweeter" id="tweeter"
                                                   value="<?php echo e($content->tweeter??''); ?>" placeholder="Tweeter"
                                                   >
                                        </div>

                                        <div class="form-group">
                                            <label for="name">LinkedIn</label>
                                            <input type="text" class="form-control" name="LinkedIn" id="LinkedIn"
                                                   value="<?php echo e($content->linkedIn??''); ?>" placeholder="LinkedIn"
                                                   >
                                        </div>

                                        <div class="form-group">
                                            <label for="name">Instagram</label>
                                            <input type="text" class="form-control" name="instagram" id="instagram"
                                                   value="<?php echo e($content->instagram??''); ?>" placeholder="instagram"
                                                   >
                                        </div>

                                            <div class="form-group">
                                                <label for="name">Logo</label>
                                                 <div class="input-group-btn">
                                                    <div class="image-upload">
                                                        <img src="<?php echo e(asset(!empty($content->logo) && file_exists('uploads/settings/'.$content->logo) ? 'uploads/settings/'.$content->logo:'admin/dist/img/placeholder.png')); ?>" class="img-responsive" width="100px" height="100px">
                                                            <div class="file-btn mt-4">
                                                                <input type="file" id="logo" name="logo" accept=".jpg,.png">
                                                                <input type="text" id="logo" name="logo" value="<?php echo e(!empty($content->logo) ? $content->logo : ''); ?>" hidden="">
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>

                                    
                              
                                    <!-- /.card-body -->
                                        <div class="card-footer float-right">
                                            <button type="submit" onclick="validateinputs()" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('admin/custom_js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp7\htdocs\app\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>